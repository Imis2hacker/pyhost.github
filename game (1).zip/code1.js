gdjs.MainGameCode = {};
gdjs.MainGameCode.GDBulletObjects2_1final = [];

gdjs.MainGameCode.GDGhostOrbObjects1_1final = [];

gdjs.MainGameCode.GDGhostOrbObjects2_1final = [];

gdjs.MainGameCode.GDRoomDoorsObjects2_1final = [];

gdjs.MainGameCode.GDRoomFloorObjects4_1final = [];

gdjs.MainGameCode.GDRoomObjects2_1final = [];

gdjs.MainGameCode.GDRoomObjects4_1final = [];

gdjs.MainGameCode.GDRoomTrapsObjects1_1final = [];

gdjs.MainGameCode.GDRoomTrapsObjects4_1final = [];

gdjs.MainGameCode.GDWesleyObjects1_1final = [];

gdjs.MainGameCode.GDWesleyObjects4_1final = [];

gdjs.MainGameCode.forEachCount0_3 = 0;

gdjs.MainGameCode.forEachCount0_4 = 0;

gdjs.MainGameCode.forEachCount1_3 = 0;

gdjs.MainGameCode.forEachCount1_4 = 0;

gdjs.MainGameCode.forEachCount2_3 = 0;

gdjs.MainGameCode.forEachCount2_4 = 0;

gdjs.MainGameCode.forEachCount3_3 = 0;

gdjs.MainGameCode.forEachCount4_3 = 0;

gdjs.MainGameCode.forEachCount5_3 = 0;

gdjs.MainGameCode.forEachCount6_3 = 0;

gdjs.MainGameCode.forEachIndex2 = 0;

gdjs.MainGameCode.forEachIndex3 = 0;

gdjs.MainGameCode.forEachIndex4 = 0;

gdjs.MainGameCode.forEachObjects2 = [];

gdjs.MainGameCode.forEachObjects3 = [];

gdjs.MainGameCode.forEachObjects4 = [];

gdjs.MainGameCode.forEachTemporary2 = null;

gdjs.MainGameCode.forEachTemporary3 = null;

gdjs.MainGameCode.forEachTotalCount2 = 0;

gdjs.MainGameCode.forEachTotalCount3 = 0;

gdjs.MainGameCode.forEachTotalCount4 = 0;

gdjs.MainGameCode.repeatCount4 = 0;

gdjs.MainGameCode.repeatIndex4 = 0;

gdjs.MainGameCode.GDRoomTrapsObjects1= [];
gdjs.MainGameCode.GDRoomTrapsObjects2= [];
gdjs.MainGameCode.GDRoomTrapsObjects3= [];
gdjs.MainGameCode.GDRoomTrapsObjects4= [];
gdjs.MainGameCode.GDRoomTrapsObjects5= [];
gdjs.MainGameCode.GDRoomTrapsObjects6= [];
gdjs.MainGameCode.GDRoomDoorsObjects1= [];
gdjs.MainGameCode.GDRoomDoorsObjects2= [];
gdjs.MainGameCode.GDRoomDoorsObjects3= [];
gdjs.MainGameCode.GDRoomDoorsObjects4= [];
gdjs.MainGameCode.GDRoomDoorsObjects5= [];
gdjs.MainGameCode.GDRoomDoorsObjects6= [];
gdjs.MainGameCode.GDRoomFloorObjects1= [];
gdjs.MainGameCode.GDRoomFloorObjects2= [];
gdjs.MainGameCode.GDRoomFloorObjects3= [];
gdjs.MainGameCode.GDRoomFloorObjects4= [];
gdjs.MainGameCode.GDRoomFloorObjects5= [];
gdjs.MainGameCode.GDRoomFloorObjects6= [];
gdjs.MainGameCode.GDRoomObjects1= [];
gdjs.MainGameCode.GDRoomObjects2= [];
gdjs.MainGameCode.GDRoomObjects3= [];
gdjs.MainGameCode.GDRoomObjects4= [];
gdjs.MainGameCode.GDRoomObjects5= [];
gdjs.MainGameCode.GDRoomObjects6= [];
gdjs.MainGameCode.GDWesleyObjects1= [];
gdjs.MainGameCode.GDWesleyObjects2= [];
gdjs.MainGameCode.GDWesleyObjects3= [];
gdjs.MainGameCode.GDWesleyObjects4= [];
gdjs.MainGameCode.GDWesleyObjects5= [];
gdjs.MainGameCode.GDWesleyObjects6= [];
gdjs.MainGameCode.GDGunObjects1= [];
gdjs.MainGameCode.GDGunObjects2= [];
gdjs.MainGameCode.GDGunObjects3= [];
gdjs.MainGameCode.GDGunObjects4= [];
gdjs.MainGameCode.GDGunObjects5= [];
gdjs.MainGameCode.GDGunObjects6= [];
gdjs.MainGameCode.GDImpObjects1= [];
gdjs.MainGameCode.GDImpObjects2= [];
gdjs.MainGameCode.GDImpObjects3= [];
gdjs.MainGameCode.GDImpObjects4= [];
gdjs.MainGameCode.GDImpObjects5= [];
gdjs.MainGameCode.GDImpObjects6= [];
gdjs.MainGameCode.GDSpiderObjects1= [];
gdjs.MainGameCode.GDSpiderObjects2= [];
gdjs.MainGameCode.GDSpiderObjects3= [];
gdjs.MainGameCode.GDSpiderObjects4= [];
gdjs.MainGameCode.GDSpiderObjects5= [];
gdjs.MainGameCode.GDSpiderObjects6= [];
gdjs.MainGameCode.GDGhostObjects1= [];
gdjs.MainGameCode.GDGhostObjects2= [];
gdjs.MainGameCode.GDGhostObjects3= [];
gdjs.MainGameCode.GDGhostObjects4= [];
gdjs.MainGameCode.GDGhostObjects5= [];
gdjs.MainGameCode.GDGhostObjects6= [];
gdjs.MainGameCode.GDGhostOrbObjects1= [];
gdjs.MainGameCode.GDGhostOrbObjects2= [];
gdjs.MainGameCode.GDGhostOrbObjects3= [];
gdjs.MainGameCode.GDGhostOrbObjects4= [];
gdjs.MainGameCode.GDGhostOrbObjects5= [];
gdjs.MainGameCode.GDGhostOrbObjects6= [];
gdjs.MainGameCode.GDBulletObjects1= [];
gdjs.MainGameCode.GDBulletObjects2= [];
gdjs.MainGameCode.GDBulletObjects3= [];
gdjs.MainGameCode.GDBulletObjects4= [];
gdjs.MainGameCode.GDBulletObjects5= [];
gdjs.MainGameCode.GDBulletObjects6= [];
gdjs.MainGameCode.GDUpgradeTextObjects1= [];
gdjs.MainGameCode.GDUpgradeTextObjects2= [];
gdjs.MainGameCode.GDUpgradeTextObjects3= [];
gdjs.MainGameCode.GDUpgradeTextObjects4= [];
gdjs.MainGameCode.GDUpgradeTextObjects5= [];
gdjs.MainGameCode.GDUpgradeTextObjects6= [];
gdjs.MainGameCode.GDEnemyDamageTextObjects1= [];
gdjs.MainGameCode.GDEnemyDamageTextObjects2= [];
gdjs.MainGameCode.GDEnemyDamageTextObjects3= [];
gdjs.MainGameCode.GDEnemyDamageTextObjects4= [];
gdjs.MainGameCode.GDEnemyDamageTextObjects5= [];
gdjs.MainGameCode.GDEnemyDamageTextObjects6= [];
gdjs.MainGameCode.GDParticle_95RecoilDustObjects1= [];
gdjs.MainGameCode.GDParticle_95RecoilDustObjects2= [];
gdjs.MainGameCode.GDParticle_95RecoilDustObjects3= [];
gdjs.MainGameCode.GDParticle_95RecoilDustObjects4= [];
gdjs.MainGameCode.GDParticle_95RecoilDustObjects5= [];
gdjs.MainGameCode.GDParticle_95RecoilDustObjects6= [];
gdjs.MainGameCode.GDParticle_95DashObjects1= [];
gdjs.MainGameCode.GDParticle_95DashObjects2= [];
gdjs.MainGameCode.GDParticle_95DashObjects3= [];
gdjs.MainGameCode.GDParticle_95DashObjects4= [];
gdjs.MainGameCode.GDParticle_95DashObjects5= [];
gdjs.MainGameCode.GDParticle_95DashObjects6= [];
gdjs.MainGameCode.GDParticle_95DeathObjects1= [];
gdjs.MainGameCode.GDParticle_95DeathObjects2= [];
gdjs.MainGameCode.GDParticle_95DeathObjects3= [];
gdjs.MainGameCode.GDParticle_95DeathObjects4= [];
gdjs.MainGameCode.GDParticle_95DeathObjects5= [];
gdjs.MainGameCode.GDParticle_95DeathObjects6= [];
gdjs.MainGameCode.GDHealthBarBorderObjects1= [];
gdjs.MainGameCode.GDHealthBarBorderObjects2= [];
gdjs.MainGameCode.GDHealthBarBorderObjects3= [];
gdjs.MainGameCode.GDHealthBarBorderObjects4= [];
gdjs.MainGameCode.GDHealthBarBorderObjects5= [];
gdjs.MainGameCode.GDHealthBarBorderObjects6= [];
gdjs.MainGameCode.GDHealthBarObjects1= [];
gdjs.MainGameCode.GDHealthBarObjects2= [];
gdjs.MainGameCode.GDHealthBarObjects3= [];
gdjs.MainGameCode.GDHealthBarObjects4= [];
gdjs.MainGameCode.GDHealthBarObjects5= [];
gdjs.MainGameCode.GDHealthBarObjects6= [];
gdjs.MainGameCode.GDDebugObjects1= [];
gdjs.MainGameCode.GDDebugObjects2= [];
gdjs.MainGameCode.GDDebugObjects3= [];
gdjs.MainGameCode.GDDebugObjects4= [];
gdjs.MainGameCode.GDDebugObjects5= [];
gdjs.MainGameCode.GDDebugObjects6= [];
gdjs.MainGameCode.GDUpgradeIconsObjects1= [];
gdjs.MainGameCode.GDUpgradeIconsObjects2= [];
gdjs.MainGameCode.GDUpgradeIconsObjects3= [];
gdjs.MainGameCode.GDUpgradeIconsObjects4= [];
gdjs.MainGameCode.GDUpgradeIconsObjects5= [];
gdjs.MainGameCode.GDUpgradeIconsObjects6= [];
gdjs.MainGameCode.GDUpgradesObjects1= [];
gdjs.MainGameCode.GDUpgradesObjects2= [];
gdjs.MainGameCode.GDUpgradesObjects3= [];
gdjs.MainGameCode.GDUpgradesObjects4= [];
gdjs.MainGameCode.GDUpgradesObjects5= [];
gdjs.MainGameCode.GDUpgradesObjects6= [];
gdjs.MainGameCode.GDTotalPointsCountObjects1= [];
gdjs.MainGameCode.GDTotalPointsCountObjects2= [];
gdjs.MainGameCode.GDTotalPointsCountObjects3= [];
gdjs.MainGameCode.GDTotalPointsCountObjects4= [];
gdjs.MainGameCode.GDTotalPointsCountObjects5= [];
gdjs.MainGameCode.GDTotalPointsCountObjects6= [];
gdjs.MainGameCode.GDTotalPointsObjects1= [];
gdjs.MainGameCode.GDTotalPointsObjects2= [];
gdjs.MainGameCode.GDTotalPointsObjects3= [];
gdjs.MainGameCode.GDTotalPointsObjects4= [];
gdjs.MainGameCode.GDTotalPointsObjects5= [];
gdjs.MainGameCode.GDTotalPointsObjects6= [];
gdjs.MainGameCode.GDDangerLevelCountObjects1= [];
gdjs.MainGameCode.GDDangerLevelCountObjects2= [];
gdjs.MainGameCode.GDDangerLevelCountObjects3= [];
gdjs.MainGameCode.GDDangerLevelCountObjects4= [];
gdjs.MainGameCode.GDDangerLevelCountObjects5= [];
gdjs.MainGameCode.GDDangerLevelCountObjects6= [];
gdjs.MainGameCode.GDDangerLevelObjects1= [];
gdjs.MainGameCode.GDDangerLevelObjects2= [];
gdjs.MainGameCode.GDDangerLevelObjects3= [];
gdjs.MainGameCode.GDDangerLevelObjects4= [];
gdjs.MainGameCode.GDDangerLevelObjects5= [];
gdjs.MainGameCode.GDDangerLevelObjects6= [];
gdjs.MainGameCode.GDHealthTextObjects1= [];
gdjs.MainGameCode.GDHealthTextObjects2= [];
gdjs.MainGameCode.GDHealthTextObjects3= [];
gdjs.MainGameCode.GDHealthTextObjects4= [];
gdjs.MainGameCode.GDHealthTextObjects5= [];
gdjs.MainGameCode.GDHealthTextObjects6= [];
gdjs.MainGameCode.GDPick_95UpsObjects1= [];
gdjs.MainGameCode.GDPick_95UpsObjects2= [];
gdjs.MainGameCode.GDPick_95UpsObjects3= [];
gdjs.MainGameCode.GDPick_95UpsObjects4= [];
gdjs.MainGameCode.GDPick_95UpsObjects5= [];
gdjs.MainGameCode.GDPick_95UpsObjects6= [];
gdjs.MainGameCode.GDReset_95TimerObjects1= [];
gdjs.MainGameCode.GDReset_95TimerObjects2= [];
gdjs.MainGameCode.GDReset_95TimerObjects3= [];
gdjs.MainGameCode.GDReset_95TimerObjects4= [];
gdjs.MainGameCode.GDReset_95TimerObjects5= [];
gdjs.MainGameCode.GDReset_95TimerObjects6= [];
gdjs.MainGameCode.GDLeaderboard_95SubmitObjects1= [];
gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2= [];
gdjs.MainGameCode.GDLeaderboard_95SubmitObjects3= [];
gdjs.MainGameCode.GDLeaderboard_95SubmitObjects4= [];
gdjs.MainGameCode.GDLeaderboard_95SubmitObjects5= [];
gdjs.MainGameCode.GDLeaderboard_95SubmitObjects6= [];
gdjs.MainGameCode.GDReset_95LeaderboardObjects1= [];
gdjs.MainGameCode.GDReset_95LeaderboardObjects2= [];
gdjs.MainGameCode.GDReset_95LeaderboardObjects3= [];
gdjs.MainGameCode.GDReset_95LeaderboardObjects4= [];
gdjs.MainGameCode.GDReset_95LeaderboardObjects5= [];
gdjs.MainGameCode.GDReset_95LeaderboardObjects6= [];
gdjs.MainGameCode.GDReset_95ButtonObjects1= [];
gdjs.MainGameCode.GDReset_95ButtonObjects2= [];
gdjs.MainGameCode.GDReset_95ButtonObjects3= [];
gdjs.MainGameCode.GDReset_95ButtonObjects4= [];
gdjs.MainGameCode.GDReset_95ButtonObjects5= [];
gdjs.MainGameCode.GDReset_95ButtonObjects6= [];
gdjs.MainGameCode.GDDarkeningObjects1= [];
gdjs.MainGameCode.GDDarkeningObjects2= [];
gdjs.MainGameCode.GDDarkeningObjects3= [];
gdjs.MainGameCode.GDDarkeningObjects4= [];
gdjs.MainGameCode.GDDarkeningObjects5= [];
gdjs.MainGameCode.GDDarkeningObjects6= [];
gdjs.MainGameCode.GDLeaderboardName_95InputObjects1= [];
gdjs.MainGameCode.GDLeaderboardName_95InputObjects2= [];
gdjs.MainGameCode.GDLeaderboardName_95InputObjects3= [];
gdjs.MainGameCode.GDLeaderboardName_95InputObjects4= [];
gdjs.MainGameCode.GDLeaderboardName_95InputObjects5= [];
gdjs.MainGameCode.GDLeaderboardName_95InputObjects6= [];
gdjs.MainGameCode.GDPause_95TextObjects1= [];
gdjs.MainGameCode.GDPause_95TextObjects2= [];
gdjs.MainGameCode.GDPause_95TextObjects3= [];
gdjs.MainGameCode.GDPause_95TextObjects4= [];
gdjs.MainGameCode.GDPause_95TextObjects5= [];
gdjs.MainGameCode.GDPause_95TextObjects6= [];
gdjs.MainGameCode.GDUpgrade_95TextObjects1= [];
gdjs.MainGameCode.GDUpgrade_95TextObjects2= [];
gdjs.MainGameCode.GDUpgrade_95TextObjects3= [];
gdjs.MainGameCode.GDUpgrade_95TextObjects4= [];
gdjs.MainGameCode.GDUpgrade_95TextObjects5= [];
gdjs.MainGameCode.GDUpgrade_95TextObjects6= [];

gdjs.MainGameCode.conditionTrue_0 = {val:false};
gdjs.MainGameCode.condition0IsTrue_0 = {val:false};
gdjs.MainGameCode.condition1IsTrue_0 = {val:false};
gdjs.MainGameCode.condition2IsTrue_0 = {val:false};
gdjs.MainGameCode.condition3IsTrue_0 = {val:false};
gdjs.MainGameCode.condition4IsTrue_0 = {val:false};
gdjs.MainGameCode.conditionTrue_1 = {val:false};
gdjs.MainGameCode.condition0IsTrue_1 = {val:false};
gdjs.MainGameCode.condition1IsTrue_1 = {val:false};
gdjs.MainGameCode.condition2IsTrue_1 = {val:false};
gdjs.MainGameCode.condition3IsTrue_1 = {val:false};
gdjs.MainGameCode.condition4IsTrue_1 = {val:false};


gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradesObjects3Objects = Hashtable.newFrom({"Upgrades": gdjs.MainGameCode.GDUpgradesObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradesObjects3Objects = Hashtable.newFrom({"Upgrades": gdjs.MainGameCode.GDUpgradesObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradesObjects3Objects = Hashtable.newFrom({"Upgrades": gdjs.MainGameCode.GDUpgradesObjects3});
gdjs.MainGameCode.eventsList0 = function(runtimeScene) {

};gdjs.MainGameCode.eventsList1 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGameCode.GDRoomFloorObjects3);
gdjs.MainGameCode.GDUpgradesObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradesObjects3Objects, (( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getPointX("")) - 64, (( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradesObjects3Objects, (( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getPointX("")) + 64, (( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradesObjects3Objects, (( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getPointX("")), (( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getPointY("")), "");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Upgrades"), gdjs.MainGameCode.GDUpgradesObjects2);

for(gdjs.MainGameCode.forEachIndex3 = 0;gdjs.MainGameCode.forEachIndex3 < gdjs.MainGameCode.GDUpgradesObjects2.length;++gdjs.MainGameCode.forEachIndex3) {
gdjs.MainGameCode.GDUpgradesObjects3.length = 0;


gdjs.MainGameCode.forEachTemporary3 = gdjs.MainGameCode.GDUpgradesObjects2[gdjs.MainGameCode.forEachIndex3];
gdjs.MainGameCode.GDUpgradesObjects3.push(gdjs.MainGameCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.MainGameCode.GDUpgradesObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgradesObjects3[i].setAnimation(gdjs.randomInRange(0, 4));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDUpgradesObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgradesObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 0, 5, 0, 2, 1, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDUpgradesObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgradesObjects3[i].setOpacity(200);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDUpgradesObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgradesObjects3[i].setZOrder((gdjs.MainGameCode.GDUpgradesObjects3[i].getPointY("")));
}
}}
}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradesObjects1Objects = Hashtable.newFrom({"Upgrades": gdjs.MainGameCode.GDUpgradesObjects1});
gdjs.MainGameCode.eventsList2 = function(runtimeScene) {

{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "SceneStartSound.wav", false, 30, 1);
}
{ //Subevents
gdjs.MainGameCode.eventsList1(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Upgrades"), gdjs.MainGameCode.GDUpgradesObjects1);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradesObjects1Objects) == 2;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDUpgradesObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDUpgradesObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgradesObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomFloorObjects2Objects = Hashtable.newFrom({"RoomFloor": gdjs.MainGameCode.GDRoomFloorObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects2Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects2});
gdjs.MainGameCode.eventsList3 = function(runtimeScene) {

{



}


{

/* Reuse gdjs.MainGameCode.GDRoomFloorObjects2 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimeScale(runtimeScene) == 0.05;
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition1IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = (gdjs.evtTools.common.distanceBetweenPositions(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.MainGameCode.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects2[0].getPointX("")), (( gdjs.MainGameCode.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects2[0].getPointY(""))) < 5);
}
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDWesleyObjects2 */
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects2[i].returnVariable(gdjs.MainGameCode.GDWesleyObjects2[i].getVariables().getFromIndex(4)).setNumber(0);
}
}}

}


};gdjs.MainGameCode.eventsList4 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects2[i].getVariableNumber(gdjs.MainGameCode.GDWesleyObjects2[i].getVariables().getFromIndex(4)) == 1 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects2[k] = gdjs.MainGameCode.GDWesleyObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDWesleyObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects2[i].addForce(0, -(500), 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects2[i].getVariableNumber(gdjs.MainGameCode.GDWesleyObjects2[i].getVariables().getFromIndex(4)) == 2 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects2[k] = gdjs.MainGameCode.GDWesleyObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDWesleyObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects2[i].addForce(0, 500, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects2[i].getVariableNumber(gdjs.MainGameCode.GDWesleyObjects2[i].getVariables().getFromIndex(4)) == 3 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects2[k] = gdjs.MainGameCode.GDWesleyObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDWesleyObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects2[i].addForce(-(400), 0, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects1);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects1[i].getVariableNumber(gdjs.MainGameCode.GDWesleyObjects1[i].getVariables().getFromIndex(4)) == 4 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects1[k] = gdjs.MainGameCode.GDWesleyObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDWesleyObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects1[i].addForce(400, 0, 0);
}
}}

}


};gdjs.MainGameCode.eventsList5 = function(runtimeScene) {

{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("HealthBarBorder"), gdjs.MainGameCode.GDHealthBarBorderObjects2);
gdjs.copyArray(runtimeScene.getObjects("HealthText"), gdjs.MainGameCode.GDHealthTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGameCode.GDRoomFloorObjects2);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}{gdjs.evtTools.runtimeScene.setBackgroundColor(runtimeScene, "24;20;37");
}{gdjs.evtTools.camera.setCameraY(runtimeScene, (( gdjs.MainGameCode.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects2[0].getPointY("")), "", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, (( gdjs.MainGameCode.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects2[0].getPointX("")), "", 0);
}{for(var i = 0, len = gdjs.MainGameCode.GDHealthTextObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDHealthTextObjects2[i].setX((( gdjs.MainGameCode.GDHealthBarBorderObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDHealthBarBorderObjects2[0].getPointX("")) + ((( gdjs.MainGameCode.GDHealthBarBorderObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDHealthBarBorderObjects2[0].getWidth()) / 2) - ((gdjs.MainGameCode.GDHealthTextObjects2[i].getWidth()) / 2));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGameCode.GDRoomFloorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomFloorObjects2Objects, (( gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects2[0].getPointX("")), (( gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects2[0].getPointY("")), false);
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
gdjs.MainGameCode.condition1IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects2Objects) == 1;
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDRoomFloorObjects2 */
{gdjs.evtTools.camera.setCameraX(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), (( gdjs.MainGameCode.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects2[0].getPointX("")), 0.05), "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, gdjs.evtTools.common.lerp(gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.MainGameCode.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects2[0].getPointY("")), 0.05), "", 0);
}
{ //Subevents
gdjs.MainGameCode.eventsList3(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGameCode.GDRoomFloorObjects1);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = (gdjs.evtTools.common.distanceBetweenPositions(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0), (( gdjs.MainGameCode.GDRoomFloorObjects1.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects1[0].getPointX("")), (( gdjs.MainGameCode.GDRoomFloorObjects1.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects1[0].getPointY(""))) >= 5);
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomFloorObjects2Objects = Hashtable.newFrom({"RoomFloor": gdjs.MainGameCode.GDRoomFloorObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomObjects3Objects = Hashtable.newFrom({"Room": gdjs.MainGameCode.GDRoomObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomFloorObjects3Objects = Hashtable.newFrom({"RoomFloor": gdjs.MainGameCode.GDRoomFloorObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomTrapsObjects3Objects = Hashtable.newFrom({"RoomTraps": gdjs.MainGameCode.GDRoomTrapsObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomDoorsObjects3Objects = Hashtable.newFrom({"RoomDoors": gdjs.MainGameCode.GDRoomDoorsObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomFloorObjects4Objects = Hashtable.newFrom({"RoomFloor": gdjs.MainGameCode.GDRoomFloorObjects4});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradesObjects4Objects = Hashtable.newFrom({"Upgrades": gdjs.MainGameCode.GDUpgradesObjects4});
gdjs.MainGameCode.eventsList6 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects4);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects4);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomFloorObjects4Objects, (( gdjs.MainGameCode.GDWesleyObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects4[0].getPointX("")), (( gdjs.MainGameCode.GDWesleyObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects4[0].getPointY("")), false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDRoomObjects3, gdjs.MainGameCode.GDRoomObjects4);

gdjs.copyArray(gdjs.MainGameCode.GDRoomDoorsObjects3, gdjs.MainGameCode.GDRoomDoorsObjects4);

/* Reuse gdjs.MainGameCode.GDRoomFloorObjects4 */
{for(var i = 0, len = gdjs.MainGameCode.GDRoomObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDRoomObjects4[i].setAnimation(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("NewRoomAnimation")));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRoomDoorsObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDRoomDoorsObjects4[i].setAnimation((( gdjs.MainGameCode.GDRoomObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomObjects4[0].getAnimation()));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRoomFloorObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDRoomFloorObjects4[i].setAnimation((( gdjs.MainGameCode.GDRoomObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomObjects4[0].getAnimation()));
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDRoomTrapsObjects3, gdjs.MainGameCode.GDRoomTrapsObjects4);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomTrapsObjects4.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomTrapsObjects4[i].getAnimation() >= 3 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDRoomTrapsObjects4[k] = gdjs.MainGameCode.GDRoomTrapsObjects4[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomTrapsObjects4.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomTrapsObjects4.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomTrapsObjects4[i].getAnimation() <= 4 ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDRoomTrapsObjects4[k] = gdjs.MainGameCode.GDRoomTrapsObjects4[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomTrapsObjects4.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDRoomTrapsObjects4 */
gdjs.MainGameCode.GDUpgradesObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradesObjects4Objects, (( gdjs.MainGameCode.GDRoomTrapsObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomTrapsObjects4[0].getPointX("")), (( gdjs.MainGameCode.GDRoomTrapsObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomTrapsObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGameCode.GDUpgradesObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgradesObjects4[i].setAnimation(gdjs.randomInRange(0, 4));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDUpgradesObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgradesObjects4[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.5, 0, 5, 0, 2, 1, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDUpgradesObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgradesObjects4[i].setOpacity(200);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDUpgradesObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgradesObjects4[i].setZOrder((gdjs.MainGameCode.GDUpgradesObjects4[i].getPointY("")));
}
}}

}


{



}


{


{
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects3);

{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].clearForces();
}
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].activateBehavior("TopDownMovement", true);
}
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomFloorObjects3Objects = Hashtable.newFrom({"RoomFloor": gdjs.MainGameCode.GDRoomFloorObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomFloorObjects3Objects = Hashtable.newFrom({"RoomFloor": gdjs.MainGameCode.GDRoomFloorObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects3Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects5Objects = Hashtable.newFrom({"Ghost": gdjs.MainGameCode.GDGhostObjects5});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects5Objects = Hashtable.newFrom({"Ghost": gdjs.MainGameCode.GDGhostObjects5});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects4Objects = Hashtable.newFrom({"Ghost": gdjs.MainGameCode.GDGhostObjects4});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects4Objects = Hashtable.newFrom({"Ghost": gdjs.MainGameCode.GDGhostObjects4});
gdjs.MainGameCode.eventsList7 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) >= 0;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects5);

gdjs.MainGameCode.GDGhostObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) >= 1;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects5);

gdjs.MainGameCode.GDGhostObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) >= 2;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects4);

gdjs.MainGameCode.GDGhostObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects5Objects = Hashtable.newFrom({"Spider": gdjs.MainGameCode.GDSpiderObjects5});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects5Objects = Hashtable.newFrom({"Ghost": gdjs.MainGameCode.GDGhostObjects5});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects5Objects = Hashtable.newFrom({"Ghost": gdjs.MainGameCode.GDGhostObjects5});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects5Objects = Hashtable.newFrom({"Ghost": gdjs.MainGameCode.GDGhostObjects5});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects5Objects = Hashtable.newFrom({"Ghost": gdjs.MainGameCode.GDGhostObjects5});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects5Objects = Hashtable.newFrom({"Spider": gdjs.MainGameCode.GDSpiderObjects5});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects4Objects = Hashtable.newFrom({"Spider": gdjs.MainGameCode.GDSpiderObjects4});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects4Objects = Hashtable.newFrom({"Spider": gdjs.MainGameCode.GDSpiderObjects4});
gdjs.MainGameCode.eventsList8 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) >= 3;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects5);

gdjs.MainGameCode.GDGhostObjects5.length = 0;

gdjs.MainGameCode.GDSpiderObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) >= 4;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects5);

gdjs.MainGameCode.GDGhostObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) >= 5;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects5);

gdjs.MainGameCode.GDSpiderObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects5Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects5[0].getPointY("")) + 50), 22), "");
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) >= 6;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects4);

gdjs.MainGameCode.GDSpiderObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDImpObjects4Objects = Hashtable.newFrom({"Imp": gdjs.MainGameCode.GDImpObjects4});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects4Objects = Hashtable.newFrom({"Spider": gdjs.MainGameCode.GDSpiderObjects4});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects4Objects = Hashtable.newFrom({"Ghost": gdjs.MainGameCode.GDGhostObjects4});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects4Objects = Hashtable.newFrom({"Spider": gdjs.MainGameCode.GDSpiderObjects4});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects4Objects = Hashtable.newFrom({"Ghost": gdjs.MainGameCode.GDGhostObjects4});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDImpObjects4Objects = Hashtable.newFrom({"Imp": gdjs.MainGameCode.GDImpObjects4});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDImpObjects4Objects = Hashtable.newFrom({"Imp": gdjs.MainGameCode.GDImpObjects4});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDImpObjects4Objects = Hashtable.newFrom({"Imp": gdjs.MainGameCode.GDImpObjects4});
gdjs.MainGameCode.eventsList9 = function(runtimeScene) {

};gdjs.MainGameCode.eventsList10 = function(runtimeScene) {

{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) < 3;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList7(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) < 7;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList8(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) >= 7;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects4);

gdjs.MainGameCode.GDGhostObjects4.length = 0;

gdjs.MainGameCode.GDImpObjects4.length = 0;

gdjs.MainGameCode.GDSpiderObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDImpObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) >= 8;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects4);

gdjs.MainGameCode.GDGhostObjects4.length = 0;

gdjs.MainGameCode.GDSpiderObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) >= 9;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects4);

gdjs.MainGameCode.GDImpObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDImpObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) >= 10;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects4);

gdjs.MainGameCode.GDImpObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDImpObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDImpObjects4Objects, gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) - 120), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointX("")) + 120), 60), gdjs.randomWithStep(((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) - 50), ((( gdjs.MainGameCode.GDRoomFloorObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects4[0].getPointY("")) + 50), 22), "");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects3);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGameCode.GDImpObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects3);

gdjs.MainGameCode.forEachTotalCount4 = 0;
gdjs.MainGameCode.forEachObjects4.length = 0;
gdjs.MainGameCode.forEachCount0_4 = gdjs.MainGameCode.GDGhostObjects3.length;
gdjs.MainGameCode.forEachTotalCount4 += gdjs.MainGameCode.forEachCount0_4;
gdjs.MainGameCode.forEachObjects4.push.apply(gdjs.MainGameCode.forEachObjects4,gdjs.MainGameCode.GDGhostObjects3);
gdjs.MainGameCode.forEachCount1_4 = gdjs.MainGameCode.GDSpiderObjects3.length;
gdjs.MainGameCode.forEachTotalCount4 += gdjs.MainGameCode.forEachCount1_4;
gdjs.MainGameCode.forEachObjects4.push.apply(gdjs.MainGameCode.forEachObjects4,gdjs.MainGameCode.GDSpiderObjects3);
gdjs.MainGameCode.forEachCount2_4 = gdjs.MainGameCode.GDImpObjects3.length;
gdjs.MainGameCode.forEachTotalCount4 += gdjs.MainGameCode.forEachCount2_4;
gdjs.MainGameCode.forEachObjects4.push.apply(gdjs.MainGameCode.forEachObjects4,gdjs.MainGameCode.GDImpObjects3);
for(gdjs.MainGameCode.forEachIndex4 = 0;gdjs.MainGameCode.forEachIndex4 < gdjs.MainGameCode.forEachTotalCount4;++gdjs.MainGameCode.forEachIndex4) {
gdjs.MainGameCode.GDGhostObjects4.length = 0;

gdjs.MainGameCode.GDImpObjects4.length = 0;

gdjs.MainGameCode.GDSpiderObjects4.length = 0;


if (gdjs.MainGameCode.forEachIndex4 < gdjs.MainGameCode.forEachCount0_4) {
    gdjs.MainGameCode.GDGhostObjects4.push(gdjs.MainGameCode.forEachObjects4[gdjs.MainGameCode.forEachIndex4]);
}
else if (gdjs.MainGameCode.forEachIndex4 < gdjs.MainGameCode.forEachCount0_4+gdjs.MainGameCode.forEachCount1_4) {
    gdjs.MainGameCode.GDSpiderObjects4.push(gdjs.MainGameCode.forEachObjects4[gdjs.MainGameCode.forEachIndex4]);
}
else if (gdjs.MainGameCode.forEachIndex4 < gdjs.MainGameCode.forEachCount0_4+gdjs.MainGameCode.forEachCount1_4+gdjs.MainGameCode.forEachCount2_4) {
    gdjs.MainGameCode.GDImpObjects4.push(gdjs.MainGameCode.forEachObjects4[gdjs.MainGameCode.forEachIndex4]);
}
if (true) {
{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects4[i].getBehavior("Health").SetHealth((gdjs.MainGameCode.GDGhostObjects4[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DangerLevelRounded")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects4[i].getBehavior("Health").SetHealth((gdjs.MainGameCode.GDSpiderObjects4[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DangerLevelRounded")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs.MainGameCode.GDImpObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects4[i].getBehavior("Health").SetHealth((gdjs.MainGameCode.GDImpObjects4[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) * gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DangerLevelRounded")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}
}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects2Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects2});
gdjs.MainGameCode.eventsList11 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects2, gdjs.MainGameCode.GDRoomFloorObjects3);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects3);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects3[i].getY() <= (( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getPointY("")) - 50 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects3[k] = gdjs.MainGameCode.GDWesleyObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDRoomFloorObjects3 */
/* Reuse gdjs.MainGameCode.GDWesleyObjects3 */
{runtimeScene.getVariables().get("NewRoomDeltaX").setNumber(0);
}{runtimeScene.getVariables().get("NewRoomDeltaY").setNumber(-((( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getHeight())));
}{runtimeScene.getVariables().get("NewRoomAnimation").setNumber(gdjs.random(1));
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].returnVariable(gdjs.MainGameCode.GDWesleyObjects3[i].getVariables().getFromIndex(4)).setNumber(1);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects2, gdjs.MainGameCode.GDRoomFloorObjects3);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects3);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects3[i].getY() >= (( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getPointY("")) + 50 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects3[k] = gdjs.MainGameCode.GDWesleyObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDRoomFloorObjects3 */
/* Reuse gdjs.MainGameCode.GDWesleyObjects3 */
{runtimeScene.getVariables().get("NewRoomDeltaX").setNumber(0);
}{runtimeScene.getVariables().get("NewRoomDeltaY").setNumber((( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getHeight()));
}{runtimeScene.getVariables().get("NewRoomAnimation").setNumber(gdjs.randomWithStep(0, 2, 2));
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].returnVariable(gdjs.MainGameCode.GDWesleyObjects3[i].getVariables().getFromIndex(4)).setNumber(2);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects2, gdjs.MainGameCode.GDRoomFloorObjects3);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects3);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects3[i].getX() <= (( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getPointX("")) - 50 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects3[k] = gdjs.MainGameCode.GDWesleyObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDRoomFloorObjects3 */
/* Reuse gdjs.MainGameCode.GDWesleyObjects3 */
{runtimeScene.getVariables().get("NewRoomDeltaX").setNumber(-((( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getWidth())));
}{runtimeScene.getVariables().get("NewRoomDeltaY").setNumber(0);
}{runtimeScene.getVariables().get("NewRoomAnimation").setNumber(gdjs.randomWithStep(0, 3, 3));
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].returnVariable(gdjs.MainGameCode.GDWesleyObjects3[i].getVariables().getFromIndex(4)).setNumber(3);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects2, gdjs.MainGameCode.GDRoomFloorObjects3);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects3);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects3[i].getX() >= (( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getPointX("")) + 50 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects3[k] = gdjs.MainGameCode.GDWesleyObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDRoomFloorObjects3 */
/* Reuse gdjs.MainGameCode.GDWesleyObjects3 */
{runtimeScene.getVariables().get("NewRoomDeltaX").setNumber((( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getWidth()));
}{runtimeScene.getVariables().get("NewRoomDeltaY").setNumber(0);
}{runtimeScene.getVariables().get("NewRoomAnimation").setNumber(gdjs.randomWithStep(0, 3, 3));
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].returnVariable(gdjs.MainGameCode.GDWesleyObjects3[i].getVariables().getFromIndex(4)).setNumber(4);
}
}}

}


{



}


{


{
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects2, gdjs.MainGameCode.GDRoomFloorObjects3);

gdjs.MainGameCode.GDRoomObjects3.length = 0;

gdjs.MainGameCode.GDRoomDoorsObjects3.length = 0;

gdjs.MainGameCode.GDRoomTrapsObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomObjects3Objects, (( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getPointX("")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("NewRoomDeltaX")), (( gdjs.MainGameCode.GDRoomFloorObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects3[0].getPointY("")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("NewRoomDeltaY")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomFloorObjects3Objects, (( gdjs.MainGameCode.GDRoomObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomObjects3[0].getPointX("")), (( gdjs.MainGameCode.GDRoomObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomTrapsObjects3Objects, (( gdjs.MainGameCode.GDRoomObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomObjects3[0].getPointX("")), (( gdjs.MainGameCode.GDRoomObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomObjects3[0].getPointY("")), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomDoorsObjects3Objects, (( gdjs.MainGameCode.GDRoomObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomObjects3[0].getPointX("")), (( gdjs.MainGameCode.GDRoomObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGameCode.GDRoomObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDRoomObjects3[i].setZOrder((gdjs.MainGameCode.GDRoomObjects3[i].getPointY("")) - 100);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRoomDoorsObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDRoomDoorsObjects3[i].setZOrder((( gdjs.MainGameCode.GDRoomObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomObjects3[0].getPointY("")) - 99);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDRoomTrapsObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDRoomTrapsObjects3[i].setAnimation(gdjs.randomInRange(0, 4));
}
}
{ //Subevents
gdjs.MainGameCode.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects2, gdjs.MainGameCode.GDRoomFloorObjects3);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects3);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
gdjs.MainGameCode.condition2IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomFloorObjects3Objects);
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
gdjs.MainGameCode.condition1IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomFloorObjects3Objects, (( gdjs.MainGameCode.GDWesleyObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects3[0].getPointX("")), (( gdjs.MainGameCode.GDWesleyObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects3[0].getPointY("")), false);
}if ( gdjs.MainGameCode.condition1IsTrue_0.val ) {
{
gdjs.MainGameCode.condition2IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects3Objects) == 1;
}}
}
if (gdjs.MainGameCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{

/* Reuse gdjs.MainGameCode.GDWesleyObjects2 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects2Objects) == 1;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0.05);
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects1Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects1});
gdjs.MainGameCode.eventsList12 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainGameCode.GDRoomTrapsObjects3, gdjs.MainGameCode.GDRoomTrapsObjects4);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects4);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.GDRoomTrapsObjects4_1final.length = 0;gdjs.MainGameCode.GDWesleyObjects4_1final.length = 0;gdjs.MainGameCode.condition0IsTrue_1.val = false;
gdjs.MainGameCode.condition1IsTrue_1.val = false;
gdjs.MainGameCode.condition2IsTrue_1.val = false;
gdjs.MainGameCode.condition3IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomTrapsObjects3, gdjs.MainGameCode.GDRoomTrapsObjects5);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects5);

for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomTrapsObjects5.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomTrapsObjects5[i].getX() > (( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointX("")) + 260 ) {
        gdjs.MainGameCode.condition0IsTrue_1.val = true;
        gdjs.MainGameCode.GDRoomTrapsObjects5[k] = gdjs.MainGameCode.GDRoomTrapsObjects5[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomTrapsObjects5.length = k;if( gdjs.MainGameCode.condition0IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomTrapsObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomTrapsObjects4_1final.indexOf(gdjs.MainGameCode.GDRoomTrapsObjects5[j]) === -1 )
            gdjs.MainGameCode.GDRoomTrapsObjects4_1final.push(gdjs.MainGameCode.GDRoomTrapsObjects5[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDWesleyObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDWesleyObjects4_1final.indexOf(gdjs.MainGameCode.GDWesleyObjects5[j]) === -1 )
            gdjs.MainGameCode.GDWesleyObjects4_1final.push(gdjs.MainGameCode.GDWesleyObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomTrapsObjects3, gdjs.MainGameCode.GDRoomTrapsObjects5);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects5);

for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomTrapsObjects5.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomTrapsObjects5[i].getX() < (( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointX("")) - 260 ) {
        gdjs.MainGameCode.condition1IsTrue_1.val = true;
        gdjs.MainGameCode.GDRoomTrapsObjects5[k] = gdjs.MainGameCode.GDRoomTrapsObjects5[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomTrapsObjects5.length = k;if( gdjs.MainGameCode.condition1IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomTrapsObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomTrapsObjects4_1final.indexOf(gdjs.MainGameCode.GDRoomTrapsObjects5[j]) === -1 )
            gdjs.MainGameCode.GDRoomTrapsObjects4_1final.push(gdjs.MainGameCode.GDRoomTrapsObjects5[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDWesleyObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDWesleyObjects4_1final.indexOf(gdjs.MainGameCode.GDWesleyObjects5[j]) === -1 )
            gdjs.MainGameCode.GDWesleyObjects4_1final.push(gdjs.MainGameCode.GDWesleyObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomTrapsObjects3, gdjs.MainGameCode.GDRoomTrapsObjects5);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects5);

for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomTrapsObjects5.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomTrapsObjects5[i].getY() < (( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointY("")) - 167 ) {
        gdjs.MainGameCode.condition2IsTrue_1.val = true;
        gdjs.MainGameCode.GDRoomTrapsObjects5[k] = gdjs.MainGameCode.GDRoomTrapsObjects5[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomTrapsObjects5.length = k;if( gdjs.MainGameCode.condition2IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomTrapsObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomTrapsObjects4_1final.indexOf(gdjs.MainGameCode.GDRoomTrapsObjects5[j]) === -1 )
            gdjs.MainGameCode.GDRoomTrapsObjects4_1final.push(gdjs.MainGameCode.GDRoomTrapsObjects5[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDWesleyObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDWesleyObjects4_1final.indexOf(gdjs.MainGameCode.GDWesleyObjects5[j]) === -1 )
            gdjs.MainGameCode.GDWesleyObjects4_1final.push(gdjs.MainGameCode.GDWesleyObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomTrapsObjects3, gdjs.MainGameCode.GDRoomTrapsObjects5);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects5);

for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomTrapsObjects5.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomTrapsObjects5[i].getY() > (( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointY("")) + 167 ) {
        gdjs.MainGameCode.condition3IsTrue_1.val = true;
        gdjs.MainGameCode.GDRoomTrapsObjects5[k] = gdjs.MainGameCode.GDRoomTrapsObjects5[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomTrapsObjects5.length = k;if( gdjs.MainGameCode.condition3IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomTrapsObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomTrapsObjects4_1final.indexOf(gdjs.MainGameCode.GDRoomTrapsObjects5[j]) === -1 )
            gdjs.MainGameCode.GDRoomTrapsObjects4_1final.push(gdjs.MainGameCode.GDRoomTrapsObjects5[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDWesleyObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDWesleyObjects4_1final.indexOf(gdjs.MainGameCode.GDWesleyObjects5[j]) === -1 )
            gdjs.MainGameCode.GDWesleyObjects4_1final.push(gdjs.MainGameCode.GDWesleyObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomTrapsObjects4_1final, gdjs.MainGameCode.GDRoomTrapsObjects4);
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects4_1final, gdjs.MainGameCode.GDWesleyObjects4);
}
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDRoomTrapsObjects4 */
{for(var i = 0, len = gdjs.MainGameCode.GDRoomTrapsObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDRoomTrapsObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(gdjs.MainGameCode.GDRoomObjects3, gdjs.MainGameCode.GDRoomObjects4);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects4);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.GDRoomObjects4_1final.length = 0;gdjs.MainGameCode.GDWesleyObjects4_1final.length = 0;gdjs.MainGameCode.condition0IsTrue_1.val = false;
gdjs.MainGameCode.condition1IsTrue_1.val = false;
gdjs.MainGameCode.condition2IsTrue_1.val = false;
gdjs.MainGameCode.condition3IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomObjects3, gdjs.MainGameCode.GDRoomObjects5);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects5);

for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomObjects5.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomObjects5[i].getX() > (( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointX("")) + 260 ) {
        gdjs.MainGameCode.condition0IsTrue_1.val = true;
        gdjs.MainGameCode.GDRoomObjects5[k] = gdjs.MainGameCode.GDRoomObjects5[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomObjects5.length = k;if( gdjs.MainGameCode.condition0IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomObjects4_1final.indexOf(gdjs.MainGameCode.GDRoomObjects5[j]) === -1 )
            gdjs.MainGameCode.GDRoomObjects4_1final.push(gdjs.MainGameCode.GDRoomObjects5[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDWesleyObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDWesleyObjects4_1final.indexOf(gdjs.MainGameCode.GDWesleyObjects5[j]) === -1 )
            gdjs.MainGameCode.GDWesleyObjects4_1final.push(gdjs.MainGameCode.GDWesleyObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomObjects3, gdjs.MainGameCode.GDRoomObjects5);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects5);

for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomObjects5.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomObjects5[i].getX() < (( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointX("")) - 260 ) {
        gdjs.MainGameCode.condition1IsTrue_1.val = true;
        gdjs.MainGameCode.GDRoomObjects5[k] = gdjs.MainGameCode.GDRoomObjects5[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomObjects5.length = k;if( gdjs.MainGameCode.condition1IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomObjects4_1final.indexOf(gdjs.MainGameCode.GDRoomObjects5[j]) === -1 )
            gdjs.MainGameCode.GDRoomObjects4_1final.push(gdjs.MainGameCode.GDRoomObjects5[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDWesleyObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDWesleyObjects4_1final.indexOf(gdjs.MainGameCode.GDWesleyObjects5[j]) === -1 )
            gdjs.MainGameCode.GDWesleyObjects4_1final.push(gdjs.MainGameCode.GDWesleyObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomObjects3, gdjs.MainGameCode.GDRoomObjects5);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects5);

for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomObjects5.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomObjects5[i].getY() < (( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointY("")) - 167 ) {
        gdjs.MainGameCode.condition2IsTrue_1.val = true;
        gdjs.MainGameCode.GDRoomObjects5[k] = gdjs.MainGameCode.GDRoomObjects5[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomObjects5.length = k;if( gdjs.MainGameCode.condition2IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomObjects4_1final.indexOf(gdjs.MainGameCode.GDRoomObjects5[j]) === -1 )
            gdjs.MainGameCode.GDRoomObjects4_1final.push(gdjs.MainGameCode.GDRoomObjects5[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDWesleyObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDWesleyObjects4_1final.indexOf(gdjs.MainGameCode.GDWesleyObjects5[j]) === -1 )
            gdjs.MainGameCode.GDWesleyObjects4_1final.push(gdjs.MainGameCode.GDWesleyObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomObjects3, gdjs.MainGameCode.GDRoomObjects5);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects5);

for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomObjects5.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomObjects5[i].getY() > (( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointY("")) + 167 ) {
        gdjs.MainGameCode.condition3IsTrue_1.val = true;
        gdjs.MainGameCode.GDRoomObjects5[k] = gdjs.MainGameCode.GDRoomObjects5[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomObjects5.length = k;if( gdjs.MainGameCode.condition3IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomObjects4_1final.indexOf(gdjs.MainGameCode.GDRoomObjects5[j]) === -1 )
            gdjs.MainGameCode.GDRoomObjects4_1final.push(gdjs.MainGameCode.GDRoomObjects5[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDWesleyObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDWesleyObjects4_1final.indexOf(gdjs.MainGameCode.GDWesleyObjects5[j]) === -1 )
            gdjs.MainGameCode.GDWesleyObjects4_1final.push(gdjs.MainGameCode.GDWesleyObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomObjects4_1final, gdjs.MainGameCode.GDRoomObjects4);
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects4_1final, gdjs.MainGameCode.GDWesleyObjects4);
}
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDRoomObjects4 */
{for(var i = 0, len = gdjs.MainGameCode.GDRoomObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDRoomObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects4);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects4);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.GDRoomFloorObjects4_1final.length = 0;gdjs.MainGameCode.GDWesleyObjects4_1final.length = 0;gdjs.MainGameCode.condition0IsTrue_1.val = false;
gdjs.MainGameCode.condition1IsTrue_1.val = false;
gdjs.MainGameCode.condition2IsTrue_1.val = false;
gdjs.MainGameCode.condition3IsTrue_1.val = false;
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects5);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects5);

for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomFloorObjects5.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomFloorObjects5[i].getX() > (( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointX("")) + 260 ) {
        gdjs.MainGameCode.condition0IsTrue_1.val = true;
        gdjs.MainGameCode.GDRoomFloorObjects5[k] = gdjs.MainGameCode.GDRoomFloorObjects5[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomFloorObjects5.length = k;if( gdjs.MainGameCode.condition0IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomFloorObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomFloorObjects4_1final.indexOf(gdjs.MainGameCode.GDRoomFloorObjects5[j]) === -1 )
            gdjs.MainGameCode.GDRoomFloorObjects4_1final.push(gdjs.MainGameCode.GDRoomFloorObjects5[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDWesleyObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDWesleyObjects4_1final.indexOf(gdjs.MainGameCode.GDWesleyObjects5[j]) === -1 )
            gdjs.MainGameCode.GDWesleyObjects4_1final.push(gdjs.MainGameCode.GDWesleyObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects5);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects5);

for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomFloorObjects5.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomFloorObjects5[i].getX() < (( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointX("")) - 260 ) {
        gdjs.MainGameCode.condition1IsTrue_1.val = true;
        gdjs.MainGameCode.GDRoomFloorObjects5[k] = gdjs.MainGameCode.GDRoomFloorObjects5[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomFloorObjects5.length = k;if( gdjs.MainGameCode.condition1IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomFloorObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomFloorObjects4_1final.indexOf(gdjs.MainGameCode.GDRoomFloorObjects5[j]) === -1 )
            gdjs.MainGameCode.GDRoomFloorObjects4_1final.push(gdjs.MainGameCode.GDRoomFloorObjects5[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDWesleyObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDWesleyObjects4_1final.indexOf(gdjs.MainGameCode.GDWesleyObjects5[j]) === -1 )
            gdjs.MainGameCode.GDWesleyObjects4_1final.push(gdjs.MainGameCode.GDWesleyObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects5);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects5);

for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomFloorObjects5.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomFloorObjects5[i].getY() < (( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointY("")) - 167 ) {
        gdjs.MainGameCode.condition2IsTrue_1.val = true;
        gdjs.MainGameCode.GDRoomFloorObjects5[k] = gdjs.MainGameCode.GDRoomFloorObjects5[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomFloorObjects5.length = k;if( gdjs.MainGameCode.condition2IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomFloorObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomFloorObjects4_1final.indexOf(gdjs.MainGameCode.GDRoomFloorObjects5[j]) === -1 )
            gdjs.MainGameCode.GDRoomFloorObjects4_1final.push(gdjs.MainGameCode.GDRoomFloorObjects5[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDWesleyObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDWesleyObjects4_1final.indexOf(gdjs.MainGameCode.GDWesleyObjects5[j]) === -1 )
            gdjs.MainGameCode.GDWesleyObjects4_1final.push(gdjs.MainGameCode.GDWesleyObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects3, gdjs.MainGameCode.GDRoomFloorObjects5);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects5);

for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomFloorObjects5.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomFloorObjects5[i].getY() > (( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointY("")) + 167 ) {
        gdjs.MainGameCode.condition3IsTrue_1.val = true;
        gdjs.MainGameCode.GDRoomFloorObjects5[k] = gdjs.MainGameCode.GDRoomFloorObjects5[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomFloorObjects5.length = k;if( gdjs.MainGameCode.condition3IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomFloorObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomFloorObjects4_1final.indexOf(gdjs.MainGameCode.GDRoomFloorObjects5[j]) === -1 )
            gdjs.MainGameCode.GDRoomFloorObjects4_1final.push(gdjs.MainGameCode.GDRoomFloorObjects5[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDWesleyObjects5.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDWesleyObjects4_1final.indexOf(gdjs.MainGameCode.GDWesleyObjects5[j]) === -1 )
            gdjs.MainGameCode.GDWesleyObjects4_1final.push(gdjs.MainGameCode.GDWesleyObjects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDRoomFloorObjects4_1final, gdjs.MainGameCode.GDRoomFloorObjects4);
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects4_1final, gdjs.MainGameCode.GDWesleyObjects4);
}
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDRoomFloorObjects4 */
{for(var i = 0, len = gdjs.MainGameCode.GDRoomFloorObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDRoomFloorObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects1ObjectsGDgdjs_46MainGameCode_46GDSpiderObjects1ObjectsGDgdjs_46MainGameCode_46GDImpObjects1Objects = Hashtable.newFrom({"Ghost": gdjs.MainGameCode.GDGhostObjects1, "Spider": gdjs.MainGameCode.GDSpiderObjects1, "Imp": gdjs.MainGameCode.GDImpObjects1});
gdjs.MainGameCode.eventsList13 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("RoomDoors"), gdjs.MainGameCode.GDRoomDoorsObjects2);
{for(var i = 0, len = gdjs.MainGameCode.GDRoomDoorsObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDRoomDoorsObjects2[i].setOpacity(gdjs.MainGameCode.GDRoomDoorsObjects2[i].getOpacity() - (300 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("RoomDoors"), gdjs.MainGameCode.GDRoomDoorsObjects1);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomDoorsObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDRoomDoorsObjects1[i].getOpacity() <= 0 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDRoomDoorsObjects1[k] = gdjs.MainGameCode.GDRoomDoorsObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomDoorsObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDRoomDoorsObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDRoomDoorsObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDRoomDoorsObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGameCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Room"), gdjs.MainGameCode.GDRoomObjects2);
gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGameCode.GDRoomFloorObjects2);
gdjs.copyArray(runtimeScene.getObjects("RoomTraps"), gdjs.MainGameCode.GDRoomTrapsObjects2);

gdjs.MainGameCode.forEachTotalCount3 = 0;
gdjs.MainGameCode.forEachObjects3.length = 0;
gdjs.MainGameCode.forEachCount0_3 = gdjs.MainGameCode.GDRoomTrapsObjects2.length;
gdjs.MainGameCode.forEachTotalCount3 += gdjs.MainGameCode.forEachCount0_3;
gdjs.MainGameCode.forEachObjects3.push.apply(gdjs.MainGameCode.forEachObjects3,gdjs.MainGameCode.GDRoomTrapsObjects2);
gdjs.MainGameCode.forEachCount1_3 = gdjs.MainGameCode.GDRoomFloorObjects2.length;
gdjs.MainGameCode.forEachTotalCount3 += gdjs.MainGameCode.forEachCount1_3;
gdjs.MainGameCode.forEachObjects3.push.apply(gdjs.MainGameCode.forEachObjects3,gdjs.MainGameCode.GDRoomFloorObjects2);
gdjs.MainGameCode.forEachCount2_3 = gdjs.MainGameCode.GDRoomObjects2.length;
gdjs.MainGameCode.forEachTotalCount3 += gdjs.MainGameCode.forEachCount2_3;
gdjs.MainGameCode.forEachObjects3.push.apply(gdjs.MainGameCode.forEachObjects3,gdjs.MainGameCode.GDRoomObjects2);
for(gdjs.MainGameCode.forEachIndex3 = 0;gdjs.MainGameCode.forEachIndex3 < gdjs.MainGameCode.forEachTotalCount3;++gdjs.MainGameCode.forEachIndex3) {
gdjs.MainGameCode.GDRoomObjects3.length = 0;

gdjs.MainGameCode.GDRoomFloorObjects3.length = 0;

gdjs.MainGameCode.GDRoomTrapsObjects3.length = 0;


if (gdjs.MainGameCode.forEachIndex3 < gdjs.MainGameCode.forEachCount0_3) {
    gdjs.MainGameCode.GDRoomTrapsObjects3.push(gdjs.MainGameCode.forEachObjects3[gdjs.MainGameCode.forEachIndex3]);
}
else if (gdjs.MainGameCode.forEachIndex3 < gdjs.MainGameCode.forEachCount0_3+gdjs.MainGameCode.forEachCount1_3) {
    gdjs.MainGameCode.GDRoomFloorObjects3.push(gdjs.MainGameCode.forEachObjects3[gdjs.MainGameCode.forEachIndex3]);
}
else if (gdjs.MainGameCode.forEachIndex3 < gdjs.MainGameCode.forEachCount0_3+gdjs.MainGameCode.forEachCount1_3+gdjs.MainGameCode.forEachCount2_3) {
    gdjs.MainGameCode.GDRoomObjects3.push(gdjs.MainGameCode.forEachObjects3[gdjs.MainGameCode.forEachIndex3]);
}
if (true) {

{ //Subevents: 
gdjs.MainGameCode.eventsList12(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects1);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGameCode.GDImpObjects1);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects1);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects1ObjectsGDgdjs_46MainGameCode_46GDSpiderObjects1ObjectsGDgdjs_46MainGameCode_46GDImpObjects1Objects) <= 0;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.eventsList15 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGameCode.GDRoomFloorObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
gdjs.MainGameCode.condition2IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickNearestObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomFloorObjects2Objects, (( gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects2[0].getPointX("")), (( gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects2[0].getPointY("")), false);
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDRoomFloorObjects2.length;i<l;++i) {
    if ( !(gdjs.MainGameCode.GDRoomFloorObjects2[i].isCollidingWithPoint((( gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects2[0].getPointX("")), (( gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects2[0].getPointY("")))) ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDRoomFloorObjects2[k] = gdjs.MainGameCode.GDRoomFloorObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDRoomFloorObjects2.length = k;}if ( gdjs.MainGameCode.condition1IsTrue_0.val ) {
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition2IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11743444);
}
}}
}
if (gdjs.MainGameCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DangerLevelCount"), gdjs.MainGameCode.GDDangerLevelCountObjects2);
{runtimeScene.getVariables().getFromIndex(2).add(0.5);
}{runtimeScene.getVariables().get("DangerLevelRounded").setNumber(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(2))));
}{for(var i = 0, len = gdjs.MainGameCode.GDDangerLevelCountObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDDangerLevelCountObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().get("DangerLevelRounded")));
}
}
{ //Subevents
gdjs.MainGameCode.eventsList11(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects1);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects1Objects) == 1;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.eventsList16 = function(runtimeScene) {

};gdjs.MainGameCode.eventsList17 = function(runtimeScene) {

};gdjs.MainGameCode.eventsList18 = function(runtimeScene) {

};gdjs.MainGameCode.eventsList19 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGameCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGameCode.GDGhostOrbObjects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGameCode.GDImpObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects2);
gdjs.copyArray(runtimeScene.getObjects("Upgrades"), gdjs.MainGameCode.GDUpgradesObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);

gdjs.MainGameCode.forEachTotalCount3 = 0;
gdjs.MainGameCode.forEachObjects3.length = 0;
gdjs.MainGameCode.forEachCount0_3 = gdjs.MainGameCode.GDGhostObjects2.length;
gdjs.MainGameCode.forEachTotalCount3 += gdjs.MainGameCode.forEachCount0_3;
gdjs.MainGameCode.forEachObjects3.push.apply(gdjs.MainGameCode.forEachObjects3,gdjs.MainGameCode.GDGhostObjects2);
gdjs.MainGameCode.forEachCount1_3 = gdjs.MainGameCode.GDWesleyObjects2.length;
gdjs.MainGameCode.forEachTotalCount3 += gdjs.MainGameCode.forEachCount1_3;
gdjs.MainGameCode.forEachObjects3.push.apply(gdjs.MainGameCode.forEachObjects3,gdjs.MainGameCode.GDWesleyObjects2);
gdjs.MainGameCode.forEachCount2_3 = gdjs.MainGameCode.GDBulletObjects2.length;
gdjs.MainGameCode.forEachTotalCount3 += gdjs.MainGameCode.forEachCount2_3;
gdjs.MainGameCode.forEachObjects3.push.apply(gdjs.MainGameCode.forEachObjects3,gdjs.MainGameCode.GDBulletObjects2);
gdjs.MainGameCode.forEachCount3_3 = gdjs.MainGameCode.GDUpgradesObjects2.length;
gdjs.MainGameCode.forEachTotalCount3 += gdjs.MainGameCode.forEachCount3_3;
gdjs.MainGameCode.forEachObjects3.push.apply(gdjs.MainGameCode.forEachObjects3,gdjs.MainGameCode.GDUpgradesObjects2);
gdjs.MainGameCode.forEachCount4_3 = gdjs.MainGameCode.GDSpiderObjects2.length;
gdjs.MainGameCode.forEachTotalCount3 += gdjs.MainGameCode.forEachCount4_3;
gdjs.MainGameCode.forEachObjects3.push.apply(gdjs.MainGameCode.forEachObjects3,gdjs.MainGameCode.GDSpiderObjects2);
gdjs.MainGameCode.forEachCount5_3 = gdjs.MainGameCode.GDImpObjects2.length;
gdjs.MainGameCode.forEachTotalCount3 += gdjs.MainGameCode.forEachCount5_3;
gdjs.MainGameCode.forEachObjects3.push.apply(gdjs.MainGameCode.forEachObjects3,gdjs.MainGameCode.GDImpObjects2);
gdjs.MainGameCode.forEachCount6_3 = gdjs.MainGameCode.GDGhostOrbObjects2.length;
gdjs.MainGameCode.forEachTotalCount3 += gdjs.MainGameCode.forEachCount6_3;
gdjs.MainGameCode.forEachObjects3.push.apply(gdjs.MainGameCode.forEachObjects3,gdjs.MainGameCode.GDGhostOrbObjects2);
for(gdjs.MainGameCode.forEachIndex3 = 0;gdjs.MainGameCode.forEachIndex3 < gdjs.MainGameCode.forEachTotalCount3;++gdjs.MainGameCode.forEachIndex3) {
gdjs.MainGameCode.GDBulletObjects3.length = 0;

gdjs.MainGameCode.GDGhostObjects3.length = 0;

gdjs.MainGameCode.GDGhostOrbObjects3.length = 0;

gdjs.MainGameCode.GDImpObjects3.length = 0;

gdjs.MainGameCode.GDSpiderObjects3.length = 0;

gdjs.MainGameCode.GDUpgradesObjects3.length = 0;

gdjs.MainGameCode.GDWesleyObjects3.length = 0;


if (gdjs.MainGameCode.forEachIndex3 < gdjs.MainGameCode.forEachCount0_3) {
    gdjs.MainGameCode.GDGhostObjects3.push(gdjs.MainGameCode.forEachObjects3[gdjs.MainGameCode.forEachIndex3]);
}
else if (gdjs.MainGameCode.forEachIndex3 < gdjs.MainGameCode.forEachCount0_3+gdjs.MainGameCode.forEachCount1_3) {
    gdjs.MainGameCode.GDWesleyObjects3.push(gdjs.MainGameCode.forEachObjects3[gdjs.MainGameCode.forEachIndex3]);
}
else if (gdjs.MainGameCode.forEachIndex3 < gdjs.MainGameCode.forEachCount0_3+gdjs.MainGameCode.forEachCount1_3+gdjs.MainGameCode.forEachCount2_3) {
    gdjs.MainGameCode.GDBulletObjects3.push(gdjs.MainGameCode.forEachObjects3[gdjs.MainGameCode.forEachIndex3]);
}
else if (gdjs.MainGameCode.forEachIndex3 < gdjs.MainGameCode.forEachCount0_3+gdjs.MainGameCode.forEachCount1_3+gdjs.MainGameCode.forEachCount2_3+gdjs.MainGameCode.forEachCount3_3) {
    gdjs.MainGameCode.GDUpgradesObjects3.push(gdjs.MainGameCode.forEachObjects3[gdjs.MainGameCode.forEachIndex3]);
}
else if (gdjs.MainGameCode.forEachIndex3 < gdjs.MainGameCode.forEachCount0_3+gdjs.MainGameCode.forEachCount1_3+gdjs.MainGameCode.forEachCount2_3+gdjs.MainGameCode.forEachCount3_3+gdjs.MainGameCode.forEachCount4_3) {
    gdjs.MainGameCode.GDSpiderObjects3.push(gdjs.MainGameCode.forEachObjects3[gdjs.MainGameCode.forEachIndex3]);
}
else if (gdjs.MainGameCode.forEachIndex3 < gdjs.MainGameCode.forEachCount0_3+gdjs.MainGameCode.forEachCount1_3+gdjs.MainGameCode.forEachCount2_3+gdjs.MainGameCode.forEachCount3_3+gdjs.MainGameCode.forEachCount4_3+gdjs.MainGameCode.forEachCount5_3) {
    gdjs.MainGameCode.GDImpObjects3.push(gdjs.MainGameCode.forEachObjects3[gdjs.MainGameCode.forEachIndex3]);
}
else if (gdjs.MainGameCode.forEachIndex3 < gdjs.MainGameCode.forEachCount0_3+gdjs.MainGameCode.forEachCount1_3+gdjs.MainGameCode.forEachCount2_3+gdjs.MainGameCode.forEachCount3_3+gdjs.MainGameCode.forEachCount4_3+gdjs.MainGameCode.forEachCount5_3+gdjs.MainGameCode.forEachCount6_3) {
    gdjs.MainGameCode.GDGhostOrbObjects3.push(gdjs.MainGameCode.forEachObjects3[gdjs.MainGameCode.forEachIndex3]);
}
if (true) {
{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects3[i].setZOrder((gdjs.MainGameCode.GDGhostObjects3[i].getPointY("")));
}
for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].setZOrder((gdjs.MainGameCode.GDWesleyObjects3[i].getPointY("")));
}
for(var i = 0, len = gdjs.MainGameCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDBulletObjects3[i].setZOrder((gdjs.MainGameCode.GDBulletObjects3[i].getPointY("")));
}
for(var i = 0, len = gdjs.MainGameCode.GDUpgradesObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgradesObjects3[i].setZOrder((gdjs.MainGameCode.GDUpgradesObjects3[i].getPointY("")));
}
for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects3[i].setZOrder((gdjs.MainGameCode.GDSpiderObjects3[i].getPointY("")));
}
for(var i = 0, len = gdjs.MainGameCode.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects3[i].setZOrder((gdjs.MainGameCode.GDImpObjects3[i].getPointY("")));
}
for(var i = 0, len = gdjs.MainGameCode.GDGhostOrbObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostOrbObjects3[i].setZOrder((gdjs.MainGameCode.GDGhostOrbObjects3[i].getPointY("")));
}
}}
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGameCode.GDGunObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);
{for(var i = 0, len = gdjs.MainGameCode.GDGunObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDGunObjects2[i].setZOrder((( gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects2[0].getPointY("")) + 1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGameCode.GDRoomFloorObjects2);

for(gdjs.MainGameCode.forEachIndex3 = 0;gdjs.MainGameCode.forEachIndex3 < gdjs.MainGameCode.GDRoomFloorObjects2.length;++gdjs.MainGameCode.forEachIndex3) {
gdjs.MainGameCode.GDRoomFloorObjects3.length = 0;


gdjs.MainGameCode.forEachTemporary3 = gdjs.MainGameCode.GDRoomFloorObjects2[gdjs.MainGameCode.forEachIndex3];
gdjs.MainGameCode.GDRoomFloorObjects3.push(gdjs.MainGameCode.forEachTemporary3);
if (true) {
{for(var i = 0, len = gdjs.MainGameCode.GDRoomFloorObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDRoomFloorObjects3[i].setZOrder((gdjs.MainGameCode.GDRoomFloorObjects3[i].getPointY("")) - 3000);
}
}}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("RoomTraps"), gdjs.MainGameCode.GDRoomTrapsObjects1);

for(gdjs.MainGameCode.forEachIndex2 = 0;gdjs.MainGameCode.forEachIndex2 < gdjs.MainGameCode.GDRoomTrapsObjects1.length;++gdjs.MainGameCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("RoomFloor"), gdjs.MainGameCode.GDRoomFloorObjects2);
gdjs.MainGameCode.GDRoomTrapsObjects2.length = 0;


gdjs.MainGameCode.forEachTemporary2 = gdjs.MainGameCode.GDRoomTrapsObjects1[gdjs.MainGameCode.forEachIndex2];
gdjs.MainGameCode.GDRoomTrapsObjects2.push(gdjs.MainGameCode.forEachTemporary2);
if (true) {
{for(var i = 0, len = gdjs.MainGameCode.GDRoomTrapsObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDRoomTrapsObjects2[i].setZOrder((( gdjs.MainGameCode.GDRoomFloorObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDRoomFloorObjects2[0].getPointY("")) - 2000);
}
}}
}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomObjects2Objects = Hashtable.newFrom({"Room": gdjs.MainGameCode.GDRoomObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomDoorsObjects2Objects = Hashtable.newFrom({"RoomDoors": gdjs.MainGameCode.GDRoomDoorsObjects2});
gdjs.MainGameCode.eventsList20 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGameCode.GDGunObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects3);
{for(var i = 0, len = gdjs.MainGameCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGunObjects3[i].setPosition((( gdjs.MainGameCode.GDWesleyObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects3[0].getPointX("GunSpot")),(( gdjs.MainGameCode.GDWesleyObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects3[0].getPointY("GunSpot")));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGunObjects3[i].rotateTowardPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), 0, runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects3[i].getX() > gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects3[k] = gdjs.MainGameCode.GDWesleyObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects3.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition1IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11789012);
}
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGameCode.GDGunObjects3);
/* Reuse gdjs.MainGameCode.GDWesleyObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].flipX(true);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGunObjects3[i].flipY(true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects2[i].getX() < gdjs.evtTools.input.getMouseX(runtimeScene, "", 0) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects2[k] = gdjs.MainGameCode.GDWesleyObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects2.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition1IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11789844);
}
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGameCode.GDGunObjects2);
/* Reuse gdjs.MainGameCode.GDWesleyObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects2[i].flipX(false);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGunObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDGunObjects2[i].flipY(false);
}
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects3Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPick_9595UpsObjects3Objects = Hashtable.newFrom({"Pick_Ups": gdjs.MainGameCode.GDPick_95UpsObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects3Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPick_9595UpsObjects3Objects = Hashtable.newFrom({"Pick_Ups": gdjs.MainGameCode.GDPick_95UpsObjects3});
gdjs.MainGameCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects4, gdjs.MainGameCode.GDWesleyObjects5);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects5.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects5[i].getVariableNumber(gdjs.MainGameCode.GDWesleyObjects5[i].getVariables().getFromIndex(2)) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0).getChild("Health")) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects5[k] = gdjs.MainGameCode.GDWesleyObjects5[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects5.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("HealthText"), gdjs.MainGameCode.GDHealthTextObjects5);
/* Reuse gdjs.MainGameCode.GDWesleyObjects5 */
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects5.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects5[i].getBehavior("Health").Heal(Math.ceil(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0).getChild("Health")) / 10), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDHealthTextObjects5.length ;i < len;++i) {
    gdjs.MainGameCode.GDHealthTextObjects5[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 8, 3, 3, 0.1, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{



}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.MainGameCode.GDHealthBarObjects4);
gdjs.copyArray(runtimeScene.getObjects("HealthBarBorder"), gdjs.MainGameCode.GDHealthBarBorderObjects4);
gdjs.copyArray(runtimeScene.getObjects("HealthText"), gdjs.MainGameCode.GDHealthTextObjects4);
/* Reuse gdjs.MainGameCode.GDWesleyObjects4 */
{for(var i = 0, len = gdjs.MainGameCode.GDHealthBarObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDHealthBarObjects4[i].setWidth(gdjs.evtTools.common.clamp(0, (216 * ((( gdjs.MainGameCode.GDWesleyObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects4[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0).getChild("Health")))), 216));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects4[i].returnVariable(gdjs.MainGameCode.GDWesleyObjects4[i].getVariables().getFromIndex(2)).setNumber((gdjs.MainGameCode.GDWesleyObjects4[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDHealthTextObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDHealthTextObjects4[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.MainGameCode.GDWesleyObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDWesleyObjects4[0].getVariables()).getFromIndex(2))) + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0).getChild("Health")));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDHealthTextObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDHealthTextObjects4[i].setX((( gdjs.MainGameCode.GDHealthBarBorderObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDHealthBarBorderObjects4[0].getPointX("")) + ((( gdjs.MainGameCode.GDHealthBarBorderObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDHealthBarBorderObjects4[0].getWidth()) / 2) - ((gdjs.MainGameCode.GDHealthTextObjects4[i].getWidth()) / 2));
}
}}

}


};gdjs.MainGameCode.eventsList22 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDPick_95UpsObjects3, gdjs.MainGameCode.GDPick_95UpsObjects4);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPick_95UpsObjects4.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPick_95UpsObjects4[i].isCurrentAnimationName("HealthOrb") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPick_95UpsObjects4[k] = gdjs.MainGameCode.GDPick_95UpsObjects4[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPick_95UpsObjects4.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPick_95UpsObjects4 */
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects3, gdjs.MainGameCode.GDWesleyObjects4);

{for(var i = 0, len = gdjs.MainGameCode.GDPick_95UpsObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDPick_95UpsObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects4[i].resetTimer("PickUpPitch");
}
}
{ //Subevents
gdjs.MainGameCode.eventsList21(runtimeScene);} //End of subevents
}

}


{



}


{

/* Reuse gdjs.MainGameCode.GDPick_95UpsObjects3 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPick_95UpsObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPick_95UpsObjects3[i].isCurrentAnimationName("PointOrb") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPick_95UpsObjects3[k] = gdjs.MainGameCode.GDPick_95UpsObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPick_95UpsObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPick_95UpsObjects3 */
gdjs.copyArray(runtimeScene.getObjects("TotalPointsCount"), gdjs.MainGameCode.GDTotalPointsCountObjects3);
{for(var i = 0, len = gdjs.MainGameCode.GDPick_95UpsObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPick_95UpsObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.MainGameCode.GDTotalPointsCountObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDTotalPointsCountObjects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3))));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDTotalPointsCountObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDTotalPointsCountObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2, 2, 3, 0.1, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


};gdjs.MainGameCode.eventsList23 = function(runtimeScene) {

{



}


{

/* Reuse gdjs.MainGameCode.GDPick_95UpsObjects3 */
/* Reuse gdjs.MainGameCode.GDWesleyObjects3 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects3Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPick_9595UpsObjects3Objects, 10, false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDWesleyObjects3 */
{gdjs.evtTools.sound.playSound(runtimeScene, "PickUp.wav", false, 10, (gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGameCode.GDWesleyObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDWesleyObjects3[0].getVariables()).getFromIndex(5))));
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].returnVariable(gdjs.MainGameCode.GDWesleyObjects3[i].getVariables().getFromIndex(5)).add(0.05);
}
}
{ //Subevents
gdjs.MainGameCode.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.eventsList24 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Pick_Ups"), gdjs.MainGameCode.GDPick_95UpsObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects3Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPick_9595UpsObjects3Objects, 80, false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPick_95UpsObjects3 */
/* Reuse gdjs.MainGameCode.GDWesleyObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDPick_95UpsObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPick_95UpsObjects3[i].addForceTowardPosition((( gdjs.MainGameCode.GDWesleyObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects3[0].getPointX("")), (( gdjs.MainGameCode.GDWesleyObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects3[0].getPointY("")), 100, 0);
}
}
{ //Subevents
gdjs.MainGameCode.eventsList23(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects2[i].getTimerElapsedTimeInSecondsOrNaN("PickUpPitch") > 1 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects2[k] = gdjs.MainGameCode.GDWesleyObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDWesleyObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects2[i].returnVariable(gdjs.MainGameCode.GDWesleyObjects2[i].getVariables().getFromIndex(5)).setNumber(1);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects2[i].removeTimer("PickUpPitch");
}
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects2Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradesObjects2Objects = Hashtable.newFrom({"Upgrades": gdjs.MainGameCode.GDUpgradesObjects2});
gdjs.MainGameCode.eventsList25 = function(runtimeScene) {

{



}


{



}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.MainGameCode.GDHealthBarObjects3);
gdjs.copyArray(runtimeScene.getObjects("HealthBarBorder"), gdjs.MainGameCode.GDHealthBarBorderObjects3);
gdjs.copyArray(runtimeScene.getObjects("HealthText"), gdjs.MainGameCode.GDHealthTextObjects3);
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects3);

{for(var i = 0, len = gdjs.MainGameCode.GDHealthBarObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDHealthBarObjects3[i].setWidth(gdjs.evtTools.common.clamp(0, (216 * ((( gdjs.MainGameCode.GDWesleyObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects3[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0).getChild("Health")))), 216));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].returnVariable(gdjs.MainGameCode.GDWesleyObjects3[i].getVariables().getFromIndex(2)).setNumber((gdjs.MainGameCode.GDWesleyObjects3[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDHealthTextObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDHealthTextObjects3[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.MainGameCode.GDWesleyObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDWesleyObjects3[0].getVariables()).getFromIndex(2))) + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0).getChild("Health")));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDHealthTextObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDHealthTextObjects3[i].setX((( gdjs.MainGameCode.GDHealthBarBorderObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDHealthBarBorderObjects3[0].getPointX("")) + ((( gdjs.MainGameCode.GDHealthBarBorderObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDHealthBarBorderObjects3[0].getWidth()) / 2) - ((gdjs.MainGameCode.GDHealthTextObjects3[i].getWidth()) / 2));
}
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradeIconsObjects3Objects = Hashtable.newFrom({"UpgradeIcons": gdjs.MainGameCode.GDUpgradeIconsObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradeIconsObjects3Objects = Hashtable.newFrom({"UpgradeIcons": gdjs.MainGameCode.GDUpgradeIconsObjects3});
gdjs.MainGameCode.eventsList26 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDUpgradesObjects2, gdjs.MainGameCode.GDUpgradesObjects3);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDUpgradesObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDUpgradesObjects3[i].isCurrentAnimationName("HealthUp") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDUpgradesObjects3[k] = gdjs.MainGameCode.GDUpgradesObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDUpgradesObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).getChild("Health").add(3);
}
{ //Subevents
gdjs.MainGameCode.eventsList25(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDUpgradesObjects2, gdjs.MainGameCode.GDUpgradesObjects3);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDUpgradesObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDUpgradesObjects3[i].isCurrentAnimationName("Armor") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDUpgradesObjects3[k] = gdjs.MainGameCode.GDUpgradesObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDUpgradesObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).getChild("Defense").add(2);
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDUpgradesObjects2, gdjs.MainGameCode.GDUpgradesObjects3);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDUpgradesObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDUpgradesObjects3[i].isCurrentAnimationName("FireRate") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDUpgradesObjects3[k] = gdjs.MainGameCode.GDUpgradesObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDUpgradesObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects3);

{runtimeScene.getVariables().getFromIndex(0).getChild("FireRate").mul(0.85);
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].setVariableBoolean(gdjs.MainGameCode.GDWesleyObjects3[i].getVariables().getFromIndex(1), true);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDUpgradesObjects2, gdjs.MainGameCode.GDUpgradesObjects3);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDUpgradesObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDUpgradesObjects3[i].isCurrentAnimationName("Power") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDUpgradesObjects3[k] = gdjs.MainGameCode.GDUpgradesObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDUpgradesObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects3);

{runtimeScene.getVariables().getFromIndex(0).getChild("Power").add(2);
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].setVariableBoolean(gdjs.MainGameCode.GDWesleyObjects3[i].getVariables().getFromIndex(1), true);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDUpgradesObjects2, gdjs.MainGameCode.GDUpgradesObjects3);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDUpgradesObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDUpgradesObjects3[i].isCurrentAnimationName("Speed") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDUpgradesObjects3[k] = gdjs.MainGameCode.GDUpgradesObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDUpgradesObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects3);

{runtimeScene.getVariables().getFromIndex(0).getChild("Speedcap").add(1);
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].getBehavior("TopDownMovement").setMaxSpeed(gdjs.MainGameCode.GDWesleyObjects3[i].getBehavior("TopDownMovement").getMaxSpeed() + (25 / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0).getChild("Speedcap"))));
}
}}

}


{



}


{


{
gdjs.copyArray(gdjs.MainGameCode.GDUpgradesObjects2, gdjs.MainGameCode.GDUpgradesObjects3);

gdjs.MainGameCode.GDUpgradeIconsObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradeIconsObjects3Objects, 16 + (32 * (gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradeIconsObjects3Objects))), 64, "UI");
}{for(var i = 0, len = gdjs.MainGameCode.GDUpgradeIconsObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgradeIconsObjects3[i].setAnimationName((( gdjs.MainGameCode.GDUpgradesObjects3.length === 0 ) ? "" :gdjs.MainGameCode.GDUpgradesObjects3[0].getAnimationName()));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDUpgradeIconsObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgradeIconsObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(1, 5, 5, 5, 5, 0.1, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{


{
/* Reuse gdjs.MainGameCode.GDUpgradesObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDUpgradesObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgradesObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGameCode.eventsList27 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Upgrades"), gdjs.MainGameCode.GDUpgradesObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects2Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradesObjects2Objects, false, runtimeScene, false);
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition1IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11799884);
}
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Upgrade.wav", false, 35, 0.8);
}
{ //Subevents
gdjs.MainGameCode.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDParticle_9595DashObjects4Objects = Hashtable.newFrom({"Particle_Dash": gdjs.MainGameCode.GDParticle_95DashObjects4});
gdjs.MainGameCode.eventsList28 = function(runtimeScene) {

{


{
/* Reuse gdjs.MainGameCode.GDWesleyObjects4 */
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects4[i].addPolarForce((gdjs.MainGameCode.GDWesleyObjects4[i].getBehavior("TopDownMovement").getAngle()), 300, 1);
}
}}

}


};gdjs.MainGameCode.eventsList29 = function(runtimeScene) {

{



}


{

/* Reuse gdjs.MainGameCode.GDWesleyObjects4 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects4.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects4[i].getVariableBoolean(gdjs.MainGameCode.GDWesleyObjects4[i].getVariables().getFromIndex(0), false) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects4[k] = gdjs.MainGameCode.GDWesleyObjects4[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects4.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDWesleyObjects4 */
gdjs.MainGameCode.GDParticle_95DashObjects4.length = 0;

{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects4[i].activateBehavior("TopDownMovement", false);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects4[i].setVariableBoolean(gdjs.MainGameCode.GDWesleyObjects4[i].getVariables().getFromIndex(0), true);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects4[i].resetTimer("Dash");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDParticle_9595DashObjects4Objects, (( gdjs.MainGameCode.GDWesleyObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects4[0].getPointX("Dust")), (( gdjs.MainGameCode.GDWesleyObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects4[0].getPointY("Dust")), "");
}{for(var i = 0, len = gdjs.MainGameCode.GDParticle_95DashObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDParticle_95DashObjects4[i].setZOrder((( gdjs.MainGameCode.GDWesleyObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects4[0].getPointY("")) - 1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Dash.wav", false, 30, gdjs.randomFloatInRange(1.2, 1.4));
}
{ //Subevents
gdjs.MainGameCode.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.eventsList30 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.condition0IsTrue_1.val = false;
gdjs.MainGameCode.condition1IsTrue_1.val = false;
{
gdjs.MainGameCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if( gdjs.MainGameCode.condition0IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
}
}
{
gdjs.MainGameCode.condition1IsTrue_1.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if( gdjs.MainGameCode.condition1IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList29(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.eventsList31 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects4, gdjs.MainGameCode.GDWesleyObjects5);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects5.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects5[i].getTimerElapsedTimeInSecondsOrNaN("Dash") <= 0.2 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects5[k] = gdjs.MainGameCode.GDWesleyObjects5[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects5.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Particle_Dash"), gdjs.MainGameCode.GDParticle_95DashObjects5);
/* Reuse gdjs.MainGameCode.GDWesleyObjects5 */
{for(var i = 0, len = gdjs.MainGameCode.GDParticle_95DashObjects5.length ;i < len;++i) {
    gdjs.MainGameCode.GDParticle_95DashObjects5[i].setPosition((( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointX("Dust")),(( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointY("Dust")));
}
}}

}


{

/* Reuse gdjs.MainGameCode.GDWesleyObjects4 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects4.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects4[i].getTimerElapsedTimeInSecondsOrNaN("Dash") > 0.2 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects4[k] = gdjs.MainGameCode.GDWesleyObjects4[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects4.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDWesleyObjects4 */
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects4[i].clearForces();
}
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects4[i].activateBehavior("TopDownMovement", true);
}
}}

}


};gdjs.MainGameCode.eventsList32 = function(runtimeScene) {

{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects4);

{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects4[i].resetTimer("Dash");
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects4);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects4.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects4[i].getBehavior("TopDownMovement").isMoving() ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects4[k] = gdjs.MainGameCode.GDWesleyObjects4[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects4.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList30(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects4);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects4.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects4[i].getVariableBoolean(gdjs.MainGameCode.GDWesleyObjects4[i].getVariables().getFromIndex(0), true) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects4[k] = gdjs.MainGameCode.GDWesleyObjects4[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects4.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList31(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects3);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects3[i].getVariableBoolean(gdjs.MainGameCode.GDWesleyObjects3[i].getVariables().getFromIndex(0), true) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects3[k] = gdjs.MainGameCode.GDWesleyObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects3.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects3[i].getTimerElapsedTimeInSecondsOrNaN("Dash") > 0.5 ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects3[k] = gdjs.MainGameCode.GDWesleyObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects3.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDWesleyObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].setVariableBoolean(gdjs.MainGameCode.GDWesleyObjects3[i].getVariables().getFromIndex(0), false);
}
}}

}


};gdjs.MainGameCode.eventsList33 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects4);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects4.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects4[i].getBehavior("TopDownMovement").isMoving() ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects4[k] = gdjs.MainGameCode.GDWesleyObjects4[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects4.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDWesleyObjects4 */
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects4[i].setAnimationName("Run");
}
}}

}


{

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects4);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects4.length;i<l;++i) {
    if ( !(gdjs.MainGameCode.GDWesleyObjects4[i].getBehavior("TopDownMovement").isMoving()) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects4[k] = gdjs.MainGameCode.GDWesleyObjects4[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects4.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDWesleyObjects4 */
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects4[i].setAnimationName("Idle");
}
}}

}


{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.condition0IsTrue_1.val = false;
gdjs.MainGameCode.condition1IsTrue_1.val = false;
{
gdjs.MainGameCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if( gdjs.MainGameCode.condition0IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
}
}
{
gdjs.MainGameCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if( gdjs.MainGameCode.condition1IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects4);

{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects4[i].getBehavior("TopDownMovement").simulateControl("Up");
}
}}

}


{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.condition0IsTrue_1.val = false;
gdjs.MainGameCode.condition1IsTrue_1.val = false;
{
gdjs.MainGameCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if( gdjs.MainGameCode.condition0IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
}
}
{
gdjs.MainGameCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if( gdjs.MainGameCode.condition1IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects4);

{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects4[i].getBehavior("TopDownMovement").simulateControl("Left");
}
}}

}


{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.condition0IsTrue_1.val = false;
gdjs.MainGameCode.condition1IsTrue_1.val = false;
{
gdjs.MainGameCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if( gdjs.MainGameCode.condition0IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
}
}
{
gdjs.MainGameCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if( gdjs.MainGameCode.condition1IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects4);

{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects4[i].getBehavior("TopDownMovement").simulateControl("Right");
}
}}

}


{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.condition0IsTrue_1.val = false;
gdjs.MainGameCode.condition1IsTrue_1.val = false;
{
gdjs.MainGameCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if( gdjs.MainGameCode.condition0IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
}
}
{
gdjs.MainGameCode.condition1IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if( gdjs.MainGameCode.condition1IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects3);

{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].getBehavior("TopDownMovement").simulateControl("Down");
}
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGameCode.GDBulletObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDParticle_9595RecoilDustObjects3Objects = Hashtable.newFrom({"Particle_RecoilDust": gdjs.MainGameCode.GDParticle_95RecoilDustObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGameCode.GDBulletObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomObjects3Objects = Hashtable.newFrom({"Room": gdjs.MainGameCode.GDRoomObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGameCode.GDBulletObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomDoorsObjects3Objects = Hashtable.newFrom({"RoomDoors": gdjs.MainGameCode.GDRoomDoorsObjects3});
gdjs.MainGameCode.eventsList34 = function(runtimeScene) {

{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FireRate");
}}

}


{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
gdjs.MainGameCode.condition1IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "FireRate") > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0).getChild("FireRate"));
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGameCode.GDGunObjects3);
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects3);

gdjs.MainGameCode.GDBulletObjects3.length = 0;

gdjs.MainGameCode.GDParticle_95RecoilDustObjects3.length = 0;

{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "FireRate");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDBulletObjects3Objects, (( gdjs.MainGameCode.GDGunObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDGunObjects3[0].getPointX("BulletSpawn")), (( gdjs.MainGameCode.GDGunObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDGunObjects3[0].getPointY("BulletSpawn")), "");
}{for(var i = 0, len = gdjs.MainGameCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDBulletObjects3[i].addPolarForce((( gdjs.MainGameCode.GDGunObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDGunObjects3[0].getAngle()), 240, 1);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDBulletObjects3[i].rotateTowardPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDBulletObjects3[i].setZOrder((( gdjs.MainGameCode.GDGunObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDGunObjects3[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGunObjects3[i].setAnimationFrame(0);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGunObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.1, 3, 3, 2, 0, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Shoot.wav", false, 30, gdjs.randomFloatInRange(0.8, 1.2));
}{gdjs.evtsExt__CameraShake__CameraShake.func(runtimeScene, 0, 0, "", 0, 0.2, 0, 1, 0.1, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].resetTimer("Recoil");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].returnVariable(gdjs.MainGameCode.GDWesleyObjects3[i].getVariables().getFromIndex(3)).setNumber(((gdjs.MainGameCode.GDWesleyObjects3[i].getAngleToPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0)))) + 180);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDParticle_9595RecoilDustObjects3Objects, (( gdjs.MainGameCode.GDGunObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDGunObjects3[0].getPointX("BulletSpawn")), (( gdjs.MainGameCode.GDGunObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDGunObjects3[0].getPointY("BulletSpawn")), "");
}{for(var i = 0, len = gdjs.MainGameCode.GDParticle_95RecoilDustObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDParticle_95RecoilDustObjects3[i].setZOrder((( gdjs.MainGameCode.GDGunObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDGunObjects3[0].getZOrder()) + 100);
}
}}

}


{



}


{

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects2, gdjs.MainGameCode.GDWesleyObjects3);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects3[i].getTimerElapsedTimeInSecondsOrNaN("Recoil") <= 0.1 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects3[k] = gdjs.MainGameCode.GDWesleyObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDWesleyObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects3[i].addPolarForce((gdjs.RuntimeObject.getVariableNumber(gdjs.MainGameCode.GDWesleyObjects3[i].getVariables().getFromIndex(3))), 50, 0);
}
}}

}


{



}


{

gdjs.MainGameCode.GDBulletObjects2.length = 0;

gdjs.MainGameCode.GDRoomObjects2.length = 0;

gdjs.MainGameCode.GDRoomDoorsObjects2.length = 0;


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.GDBulletObjects2_1final.length = 0;gdjs.MainGameCode.GDRoomObjects2_1final.length = 0;gdjs.MainGameCode.GDRoomDoorsObjects2_1final.length = 0;gdjs.MainGameCode.condition0IsTrue_1.val = false;
gdjs.MainGameCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGameCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Room"), gdjs.MainGameCode.GDRoomObjects3);
gdjs.MainGameCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDBulletObjects3Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomObjects3Objects, false, runtimeScene, false);
if( gdjs.MainGameCode.condition0IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDBulletObjects3.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDBulletObjects2_1final.indexOf(gdjs.MainGameCode.GDBulletObjects3[j]) === -1 )
            gdjs.MainGameCode.GDBulletObjects2_1final.push(gdjs.MainGameCode.GDBulletObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomObjects3.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomObjects2_1final.indexOf(gdjs.MainGameCode.GDRoomObjects3[j]) === -1 )
            gdjs.MainGameCode.GDRoomObjects2_1final.push(gdjs.MainGameCode.GDRoomObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGameCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("RoomDoors"), gdjs.MainGameCode.GDRoomDoorsObjects3);
gdjs.MainGameCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDBulletObjects3Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomDoorsObjects3Objects, false, runtimeScene, false);
if( gdjs.MainGameCode.condition1IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDBulletObjects3.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDBulletObjects2_1final.indexOf(gdjs.MainGameCode.GDBulletObjects3[j]) === -1 )
            gdjs.MainGameCode.GDBulletObjects2_1final.push(gdjs.MainGameCode.GDBulletObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomDoorsObjects3.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomDoorsObjects2_1final.indexOf(gdjs.MainGameCode.GDRoomDoorsObjects3[j]) === -1 )
            gdjs.MainGameCode.GDRoomDoorsObjects2_1final.push(gdjs.MainGameCode.GDRoomDoorsObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDBulletObjects2_1final, gdjs.MainGameCode.GDBulletObjects2);
gdjs.copyArray(gdjs.MainGameCode.GDRoomObjects2_1final, gdjs.MainGameCode.GDRoomObjects2);
gdjs.copyArray(gdjs.MainGameCode.GDRoomDoorsObjects2_1final, gdjs.MainGameCode.GDRoomDoorsObjects2);
}
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDBulletObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGameCode.eventsList35 = function(runtimeScene) {

{


gdjs.MainGameCode.eventsList32(runtimeScene);
}


{


gdjs.MainGameCode.eventsList33(runtimeScene);
}


{


gdjs.MainGameCode.eventsList34(runtimeScene);
}


};gdjs.MainGameCode.eventsList36 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects2[i].getVariableNumber(gdjs.MainGameCode.GDWesleyObjects2[i].getVariables().getFromIndex(4)) == 0 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects2[k] = gdjs.MainGameCode.GDWesleyObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects2.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
gdjs.MainGameCode.condition1IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "PauseLayer"));
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostOrbObjects2Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGameCode.GDGhostOrbObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects2Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomTrapsObjects2Objects = Hashtable.newFrom({"RoomTraps": gdjs.MainGameCode.GDRoomTrapsObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects2Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostOrbObjects2Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGameCode.GDGhostOrbObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects2Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDParticle_9595DeathObjects1Objects = Hashtable.newFrom({"Particle_Death": gdjs.MainGameCode.GDParticle_95DeathObjects1});
gdjs.MainGameCode.eventsList37 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainGameCode.GDGhostOrbObjects1, gdjs.MainGameCode.GDGhostOrbObjects2);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects2);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostOrbObjects2Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects2Objects, false, runtimeScene, false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDGhostOrbObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDGhostOrbObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostOrbObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{



}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("HealthBar"), gdjs.MainGameCode.GDHealthBarObjects2);
gdjs.copyArray(runtimeScene.getObjects("HealthBarBorder"), gdjs.MainGameCode.GDHealthBarBorderObjects2);
gdjs.copyArray(gdjs.MainGameCode.GDHealthTextObjects1, gdjs.MainGameCode.GDHealthTextObjects2);

gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1, gdjs.MainGameCode.GDWesleyObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDHealthBarObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDHealthBarObjects2[i].setWidth(gdjs.evtTools.common.clamp(0, (216 * ((( gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects2[0].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0).getChild("Health")))), 216));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects2[i].returnVariable(gdjs.MainGameCode.GDWesleyObjects2[i].getVariables().getFromIndex(2)).setNumber((gdjs.MainGameCode.GDWesleyObjects2[i].getBehavior("Health").Health((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDHealthTextObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDHealthTextObjects2[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDWesleyObjects2[0].getVariables()).getFromIndex(2))) + "/" + gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0).getChild("Health")));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDHealthTextObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDHealthTextObjects2[i].setX((( gdjs.MainGameCode.GDHealthBarBorderObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDHealthBarBorderObjects2[0].getPointX("")) + ((( gdjs.MainGameCode.GDHealthBarBorderObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDHealthBarBorderObjects2[0].getWidth()) / 2) - ((gdjs.MainGameCode.GDHealthTextObjects2[i].getWidth()) / 2));
}
}}

}


{



}


{

/* Reuse gdjs.MainGameCode.GDWesleyObjects1 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects1[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects1[k] = gdjs.MainGameCode.GDWesleyObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.MainGameCode.GDGunObjects1);
/* Reuse gdjs.MainGameCode.GDWesleyObjects1 */
gdjs.MainGameCode.GDParticle_95DeathObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDParticle_9595DeathObjects1Objects, (( gdjs.MainGameCode.GDWesleyObjects1.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects1[0].getPointX("")), (( gdjs.MainGameCode.GDWesleyObjects1.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGameCode.GDParticle_95DeathObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDParticle_95DeathObjects1[i].setZOrder((( gdjs.MainGameCode.GDWesleyObjects1.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects1[0].getPointY("")) + 10000);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGunObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDGunObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "DeathSound.wav", false, 50, 1);
}}

}


};gdjs.MainGameCode.eventsList38 = function(runtimeScene) {

{



}


{

gdjs.MainGameCode.GDGhostOrbObjects1.length = 0;

gdjs.MainGameCode.GDRoomTrapsObjects1.length = 0;

gdjs.MainGameCode.GDWesleyObjects1.length = 0;


gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
gdjs.MainGameCode.condition2IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.GDGhostOrbObjects1_1final.length = 0;gdjs.MainGameCode.GDRoomTrapsObjects1_1final.length = 0;gdjs.MainGameCode.GDWesleyObjects1_1final.length = 0;gdjs.MainGameCode.condition0IsTrue_1.val = false;
gdjs.MainGameCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGameCode.GDGhostOrbObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);
gdjs.MainGameCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostOrbObjects2Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects2Objects, false, runtimeScene, false);
if( gdjs.MainGameCode.condition0IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDGhostOrbObjects2.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDGhostOrbObjects1_1final.indexOf(gdjs.MainGameCode.GDGhostOrbObjects2[j]) === -1 )
            gdjs.MainGameCode.GDGhostOrbObjects1_1final.push(gdjs.MainGameCode.GDGhostOrbObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDWesleyObjects2.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDWesleyObjects1_1final.indexOf(gdjs.MainGameCode.GDWesleyObjects2[j]) === -1 )
            gdjs.MainGameCode.GDWesleyObjects1_1final.push(gdjs.MainGameCode.GDWesleyObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("RoomTraps"), gdjs.MainGameCode.GDRoomTrapsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);
gdjs.MainGameCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomTrapsObjects2Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects2Objects, false, runtimeScene, false);
if( gdjs.MainGameCode.condition1IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomTrapsObjects2.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomTrapsObjects1_1final.indexOf(gdjs.MainGameCode.GDRoomTrapsObjects2[j]) === -1 )
            gdjs.MainGameCode.GDRoomTrapsObjects1_1final.push(gdjs.MainGameCode.GDRoomTrapsObjects2[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDWesleyObjects2.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDWesleyObjects1_1final.indexOf(gdjs.MainGameCode.GDWesleyObjects2[j]) === -1 )
            gdjs.MainGameCode.GDWesleyObjects1_1final.push(gdjs.MainGameCode.GDWesleyObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDGhostOrbObjects1_1final, gdjs.MainGameCode.GDGhostOrbObjects1);
gdjs.copyArray(gdjs.MainGameCode.GDRoomTrapsObjects1_1final, gdjs.MainGameCode.GDRoomTrapsObjects1);
gdjs.copyArray(gdjs.MainGameCode.GDWesleyObjects1_1final, gdjs.MainGameCode.GDWesleyObjects1);
}
}
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects1.length;i<l;++i) {
    if ( !(gdjs.MainGameCode.GDWesleyObjects1[i].getBehavior("Flash").IsFlashing((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects1[k] = gdjs.MainGameCode.GDWesleyObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects1.length = k;}if ( gdjs.MainGameCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects1[i].getTimerElapsedTimeInSecondsOrNaN("Dash") >= 0.2 ) {
        gdjs.MainGameCode.condition2IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects1[k] = gdjs.MainGameCode.GDWesleyObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects1.length = k;}}
}
if (gdjs.MainGameCode.condition2IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("HealthText"), gdjs.MainGameCode.GDHealthTextObjects1);
/* Reuse gdjs.MainGameCode.GDWesleyObjects1 */
{gdjs.evtTools.sound.playSound(runtimeScene, "PlayerHurt.wav", false, 50, gdjs.randomFloatInRange(0.9, 1));
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects1[i].getBehavior("Flash").Flash(1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects1[i].getBehavior("Health").Hit(Math.max(0, Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("DangerLevelRounded")) - gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0).getChild("Defense"))) + 1), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDHealthTextObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDHealthTextObjects1[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 8, 3, 3, 0.1, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MainGameCode.eventsList37(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.eventsList39 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Room"), gdjs.MainGameCode.GDRoomObjects2);
gdjs.copyArray(runtimeScene.getObjects("RoomDoors"), gdjs.MainGameCode.GDRoomDoorsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);
{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects2[i].separateFromObjectsList(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomObjects2Objects, false);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDWesleyObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDWesleyObjects2[i].separateFromObjectsList(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomDoorsObjects2Objects, false);
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "PauseLayer"));
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList20(runtimeScene);} //End of subevents
}

}


{


gdjs.MainGameCode.eventsList24(runtimeScene);
}


{


gdjs.MainGameCode.eventsList27(runtimeScene);
}


{


gdjs.MainGameCode.eventsList36(runtimeScene);
}


{


gdjs.MainGameCode.eventsList38(runtimeScene);
}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomObjects2Objects = Hashtable.newFrom({"Room": gdjs.MainGameCode.GDRoomObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomObjects2Objects = Hashtable.newFrom({"Room": gdjs.MainGameCode.GDRoomObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomObjects2Objects = Hashtable.newFrom({"Room": gdjs.MainGameCode.GDRoomObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomTrapsObjects2Objects = Hashtable.newFrom({"RoomTraps": gdjs.MainGameCode.GDRoomTrapsObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomTrapsObjects2Objects = Hashtable.newFrom({"RoomTraps": gdjs.MainGameCode.GDRoomTrapsObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects2Objects = Hashtable.newFrom({"Ghost": gdjs.MainGameCode.GDGhostObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects2Objects = Hashtable.newFrom({"Spider": gdjs.MainGameCode.GDSpiderObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDImpObjects2Objects = Hashtable.newFrom({"Imp": gdjs.MainGameCode.GDImpObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects3Objects = Hashtable.newFrom({"Ghost": gdjs.MainGameCode.GDGhostObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects3Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostOrbObjects3Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGameCode.GDGhostOrbObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGameCode.GDBulletObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects3Objects = Hashtable.newFrom({"Ghost": gdjs.MainGameCode.GDGhostObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDEnemyDamageTextObjects3Objects = Hashtable.newFrom({"EnemyDamageText": gdjs.MainGameCode.GDEnemyDamageTextObjects3});
gdjs.MainGameCode.eventsList40 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDGhostObjects3[i].isCurrentAnimationName("Idle") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDGhostObjects3[k] = gdjs.MainGameCode.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDGhostObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDGhostObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects3);
{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects3[i].addForceTowardObject((gdjs.MainGameCode.GDWesleyObjects3.length !== 0 ? gdjs.MainGameCode.GDWesleyObjects3[0] : null), 10, 0);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects3[i].setOpacity(100);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDGhostObjects3[i].isCurrentAnimationName("Hurt") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDGhostObjects3[k] = gdjs.MainGameCode.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDGhostObjects3.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDGhostObjects3[i].hasAnimationEnded() ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDGhostObjects3[k] = gdjs.MainGameCode.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDGhostObjects3.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDGhostObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects3[i].setAnimationName("Idle");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects3Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects3Objects, 120, false);
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDGhostObjects3[i].isCurrentAnimationName("Idle") ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDGhostObjects3[k] = gdjs.MainGameCode.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDGhostObjects3.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDGhostObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects3[i].setAnimationName("Charging");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects3[i].setOpacity(255);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDGhostObjects3[i].isCurrentAnimationName("Charging") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDGhostObjects3[k] = gdjs.MainGameCode.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDGhostObjects3.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDGhostObjects3[i].hasAnimationEnded() ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDGhostObjects3[k] = gdjs.MainGameCode.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDGhostObjects3.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDGhostObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects3);
gdjs.MainGameCode.GDGhostOrbObjects3.length = 0;

{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects3[i].setAnimationName("Resting");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostOrbObjects3Objects, (( gdjs.MainGameCode.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDGhostObjects3[0].getPointX("GhostOrbSpawn")), (( gdjs.MainGameCode.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDGhostObjects3[0].getPointY("GhostOrbSpawn")), "");
}{for(var i = 0, len = gdjs.MainGameCode.GDGhostOrbObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostOrbObjects3[i].addForceTowardPosition((( gdjs.MainGameCode.GDWesleyObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects3[0].getPointX("")), (( gdjs.MainGameCode.GDWesleyObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects3[0].getPointY("")) + 5, 80, 1);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGhostOrbObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostOrbObjects3[i].setZOrder((( gdjs.MainGameCode.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDGhostObjects3[0].getZOrder()) - 1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "GhostFire.wav", false, 10, gdjs.randomFloatInRange(0.7, 0.9));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDGhostObjects3[i].isCurrentAnimationName("Resting") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDGhostObjects3[k] = gdjs.MainGameCode.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDGhostObjects3.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDGhostObjects3[i].hasAnimationEnded() ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDGhostObjects3[k] = gdjs.MainGameCode.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDGhostObjects3.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDGhostObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects3[i].setAnimationName("Idle");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGameCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDBulletObjects3Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects3Objects, false, runtimeScene, false);
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDGhostObjects3[i].getOpacity() == 255 ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDGhostObjects3[k] = gdjs.MainGameCode.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDGhostObjects3.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDBulletObjects3 */
/* Reuse gdjs.MainGameCode.GDGhostObjects3 */
gdjs.MainGameCode.GDEnemyDamageTextObjects3.length = 0;

{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects3[i].setAnimationName("Hurt");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "BulletHit.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.3, 4, 4, 5, 0, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects3[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0).getChild("Power")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDEnemyDamageTextObjects3Objects, (( gdjs.MainGameCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDBulletObjects3[0].getPointX("")), (( gdjs.MainGameCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDBulletObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGameCode.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDEnemyDamageTextObjects3[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0).getChild("Power")));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDEnemyDamageTextObjects3[i].addForce(0, -(25), 1);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDEnemyDamageTextObjects3[i].setZOrder((( gdjs.MainGameCode.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDGhostObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects3[i].resetTimer("Knockback");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects3[i].returnVariable(gdjs.MainGameCode.GDGhostObjects3[i].getVariables().get("KnockBackAngle")).setNumber((( gdjs.MainGameCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDBulletObjects3[0].getAngle()));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDGhostObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDGhostObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Knockback") <= 0.1 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDGhostObjects2[k] = gdjs.MainGameCode.GDGhostObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDGhostObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDGhostObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects2[i].addPolarForce((gdjs.RuntimeObject.getVariableNumber(gdjs.MainGameCode.GDGhostObjects2[i].getVariables().get("KnockBackAngle"))), 50, 0);
}
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects3Objects = Hashtable.newFrom({"Spider": gdjs.MainGameCode.GDSpiderObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects3Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostOrbObjects4Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGameCode.GDGhostOrbObjects4});
gdjs.MainGameCode.eventsList41 = function(runtimeScene) {

};gdjs.MainGameCode.eventsList42 = function(runtimeScene) {

{


gdjs.MainGameCode.repeatCount4 = 7;
for(gdjs.MainGameCode.repeatIndex4 = 0;gdjs.MainGameCode.repeatIndex4 < gdjs.MainGameCode.repeatCount4;++gdjs.MainGameCode.repeatIndex4) {
gdjs.copyArray(gdjs.MainGameCode.GDSpiderObjects3, gdjs.MainGameCode.GDSpiderObjects4);

gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects4);
gdjs.MainGameCode.GDGhostOrbObjects4.length = 0;


if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostOrbObjects4Objects, (( gdjs.MainGameCode.GDSpiderObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDSpiderObjects4[0].getPointX("GhostOrbSpawn")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("i"))).getChild("X")), (( gdjs.MainGameCode.GDSpiderObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDSpiderObjects4[0].getPointY("GhostOrbSpawn")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("i"))).getChild("Y")), "");
}{for(var i = 0, len = gdjs.MainGameCode.GDGhostOrbObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostOrbObjects4[i].addForceTowardPosition((( gdjs.MainGameCode.GDWesleyObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects4[0].getPointX("")) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("i"))).getChild("X")), (( gdjs.MainGameCode.GDWesleyObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects4[0].getPointY("")) + 5 + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4).getChild(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().get("i"))).getChild("Y")), 20, 1);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGhostOrbObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostOrbObjects4[i].setZOrder((( gdjs.MainGameCode.GDSpiderObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDSpiderObjects4[0].getZOrder()) - 1);
}
}{runtimeScene.getVariables().get("i").add(1);
}}
}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGameCode.GDBulletObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects3Objects = Hashtable.newFrom({"Spider": gdjs.MainGameCode.GDSpiderObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDEnemyDamageTextObjects3Objects = Hashtable.newFrom({"EnemyDamageText": gdjs.MainGameCode.GDEnemyDamageTextObjects3});
gdjs.MainGameCode.eventsList43 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDSpiderObjects3[i].isCurrentAnimationName("Idle") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDSpiderObjects3[k] = gdjs.MainGameCode.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDSpiderObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDSpiderObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects3);
{for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects3[i].addForceTowardObject((gdjs.MainGameCode.GDWesleyObjects3.length !== 0 ? gdjs.MainGameCode.GDWesleyObjects3[0] : null), 60, 0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDSpiderObjects3[i].isCurrentAnimationName("Hurt") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDSpiderObjects3[k] = gdjs.MainGameCode.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDSpiderObjects3.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDSpiderObjects3[i].hasAnimationEnded() ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDSpiderObjects3[k] = gdjs.MainGameCode.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDSpiderObjects3.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDSpiderObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects3[i].setAnimationName("Idle");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects3Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects3Objects, 15, false);
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDSpiderObjects3[i].isCurrentAnimationName("Idle") ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDSpiderObjects3[k] = gdjs.MainGameCode.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDSpiderObjects3.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDSpiderObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects3[i].setAnimationName("Charging");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDSpiderObjects3[i].isCurrentAnimationName("Charging") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDSpiderObjects3[k] = gdjs.MainGameCode.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDSpiderObjects3.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDSpiderObjects3[i].hasAnimationEnded() ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDSpiderObjects3[k] = gdjs.MainGameCode.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDSpiderObjects3.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDSpiderObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects3[i].setAnimationName("Resting");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "SpiderNoise.wav", false, 10, gdjs.randomFloatInRange(1, 1.2));
}{runtimeScene.getVariables().get("i").setNumber(0);
}
{ //Subevents
gdjs.MainGameCode.eventsList42(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDSpiderObjects3[i].isCurrentAnimationName("Resting") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDSpiderObjects3[k] = gdjs.MainGameCode.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDSpiderObjects3.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDSpiderObjects3[i].hasAnimationEnded() ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDSpiderObjects3[k] = gdjs.MainGameCode.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDSpiderObjects3.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDSpiderObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects3[i].setAnimationName("Idle");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGameCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDBulletObjects3Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects3Objects, false, runtimeScene, false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDBulletObjects3 */
/* Reuse gdjs.MainGameCode.GDSpiderObjects3 */
gdjs.MainGameCode.GDEnemyDamageTextObjects3.length = 0;

{for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects3[i].setAnimationName("Hurt");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "BulletHit.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.3, 3, 3, 4, 0, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects3[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0).getChild("Power")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDEnemyDamageTextObjects3Objects, (( gdjs.MainGameCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDBulletObjects3[0].getPointX("")), (( gdjs.MainGameCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDBulletObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGameCode.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDEnemyDamageTextObjects3[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0).getChild("Power")));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDEnemyDamageTextObjects3[i].addForce(0, -(25), 1);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDEnemyDamageTextObjects3[i].setZOrder((( gdjs.MainGameCode.GDSpiderObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDSpiderObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects3[i].resetTimer("Knockback");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects3[i].returnVariable(gdjs.MainGameCode.GDSpiderObjects3[i].getVariables().get("KnockBackAngle")).setNumber((( gdjs.MainGameCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDBulletObjects3[0].getAngle()));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDSpiderObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDSpiderObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Knockback") <= 0.1 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDSpiderObjects2[k] = gdjs.MainGameCode.GDSpiderObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDSpiderObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDSpiderObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects2[i].addPolarForce((gdjs.RuntimeObject.getVariableNumber(gdjs.MainGameCode.GDSpiderObjects2[i].getVariables().get("KnockBackAngle"))), 40, 0);
}
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDImpObjects3Objects = Hashtable.newFrom({"Imp": gdjs.MainGameCode.GDImpObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects3Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostOrbObjects5Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGameCode.GDGhostOrbObjects5});
gdjs.MainGameCode.eventsList44 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.MainGameCode.GDImpObjects4, gdjs.MainGameCode.GDImpObjects5);

gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects5);
gdjs.MainGameCode.GDGhostOrbObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostOrbObjects5Objects, (( gdjs.MainGameCode.GDImpObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDImpObjects5[0].getPointX("GhostOrbSpawn")), (( gdjs.MainGameCode.GDImpObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDImpObjects5[0].getPointY("GhostOrbSpawn")), "");
}{for(var i = 0, len = gdjs.MainGameCode.GDGhostOrbObjects5.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostOrbObjects5[i].setZOrder((( gdjs.MainGameCode.GDImpObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDImpObjects5[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGhostOrbObjects5.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostOrbObjects5[i].addPolarForce(gdjs.evtTools.common.angleBetweenPositions((( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointX("")), (( gdjs.MainGameCode.GDWesleyObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects5[0].getPointY("")) + 5, (( gdjs.MainGameCode.GDImpObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDImpObjects5[0].getPointX("GhostOrbSpawn")), (( gdjs.MainGameCode.GDImpObjects5.length === 0 ) ? 0 :gdjs.MainGameCode.GDImpObjects5[0].getPointY("GhostOrbSpawn"))) + (gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGameCode.GDImpObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDImpObjects5[0].getVariables()).get("Spread"))), 40, 1);
}
}}

}


};gdjs.MainGameCode.eventsList45 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(gdjs.MainGameCode.GDImpObjects3, gdjs.MainGameCode.GDImpObjects4);

{for(var i = 0, len = gdjs.MainGameCode.GDImpObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects4[i].returnVariable(gdjs.MainGameCode.GDImpObjects4[i].getVariables().get("Spread")).setNumber(130);
}
}}

}


{


gdjs.MainGameCode.repeatCount4 = 9;
for(gdjs.MainGameCode.repeatIndex4 = 0;gdjs.MainGameCode.repeatIndex4 < gdjs.MainGameCode.repeatCount4;++gdjs.MainGameCode.repeatIndex4) {
gdjs.copyArray(gdjs.MainGameCode.GDImpObjects3, gdjs.MainGameCode.GDImpObjects4);


if (true)
{
{for(var i = 0, len = gdjs.MainGameCode.GDImpObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects4[i].returnVariable(gdjs.MainGameCode.GDImpObjects4[i].getVariables().get("Spread")).add(10);
}
}
{ //Subevents: 
gdjs.MainGameCode.eventsList44(runtimeScene);} //Subevents end.
}
}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.MainGameCode.GDBulletObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDImpObjects3Objects = Hashtable.newFrom({"Imp": gdjs.MainGameCode.GDImpObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDEnemyDamageTextObjects3Objects = Hashtable.newFrom({"EnemyDamageText": gdjs.MainGameCode.GDEnemyDamageTextObjects3});
gdjs.MainGameCode.eventsList46 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGameCode.GDImpObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDImpObjects3[i].isCurrentAnimationName("Idle") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDImpObjects3[k] = gdjs.MainGameCode.GDImpObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDImpObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDImpObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects3);
{for(var i = 0, len = gdjs.MainGameCode.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects3[i].addForceTowardObject((gdjs.MainGameCode.GDWesleyObjects3.length !== 0 ? gdjs.MainGameCode.GDWesleyObjects3[0] : null), 18, 0);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGameCode.GDImpObjects3);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.distanceTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDImpObjects3Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects3Objects, 140, false);
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDImpObjects3[i].isCurrentAnimationName("Idle") ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDImpObjects3[k] = gdjs.MainGameCode.GDImpObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDImpObjects3.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDImpObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects3[i].setAnimationName("Charging");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ImpHop.wav", false, 10, gdjs.randomFloatInRange(1, 1.2));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGameCode.GDImpObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDImpObjects3[i].isCurrentAnimationName("Charging") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDImpObjects3[k] = gdjs.MainGameCode.GDImpObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDImpObjects3.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDImpObjects3[i].hasAnimationEnded() ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDImpObjects3[k] = gdjs.MainGameCode.GDImpObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDImpObjects3.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDImpObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects3[i].setAnimationName("Resting");
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ImpStomp.wav", false, 20, gdjs.randomFloatInRange(1, 1.2));
}
{ //Subevents
gdjs.MainGameCode.eventsList45(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGameCode.GDImpObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDImpObjects3[i].isCurrentAnimationName("Resting") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDImpObjects3[k] = gdjs.MainGameCode.GDImpObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDImpObjects3.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDImpObjects3[i].hasAnimationEnded() ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDImpObjects3[k] = gdjs.MainGameCode.GDImpObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDImpObjects3.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDImpObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects3[i].setAnimationName("Idle");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.MainGameCode.GDBulletObjects3);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGameCode.GDImpObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDBulletObjects3Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDImpObjects3Objects, false, runtimeScene, false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDBulletObjects3 */
/* Reuse gdjs.MainGameCode.GDImpObjects3 */
gdjs.MainGameCode.GDEnemyDamageTextObjects3.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "BulletHit.wav", false, 60, gdjs.randomFloatInRange(0.9, 1));
}{for(var i = 0, len = gdjs.MainGameCode.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects3[i].getBehavior("ShakeObject_PositionAngleScale").ShakeObject_PositionAngleScale(0.3, 2, 2, 2, 0, 0.08, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects3[i].getBehavior("Health").Hit(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0).getChild("Power")), (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDEnemyDamageTextObjects3Objects, (( gdjs.MainGameCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDBulletObjects3[0].getPointX("")), (( gdjs.MainGameCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDBulletObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGameCode.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDEnemyDamageTextObjects3[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(0).getChild("Power")));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDEnemyDamageTextObjects3[i].addForce(0, -(25), 1);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDEnemyDamageTextObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDEnemyDamageTextObjects3[i].setZOrder((( gdjs.MainGameCode.GDImpObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDImpObjects3[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects3[i].resetTimer("Knockback");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDImpObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects3[i].returnVariable(gdjs.MainGameCode.GDImpObjects3[i].getVariables().get("KnockBackAngle")).setNumber((( gdjs.MainGameCode.GDBulletObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDBulletObjects3[0].getAngle()));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDBulletObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDBulletObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGameCode.GDImpObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDImpObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDImpObjects2[i].getTimerElapsedTimeInSecondsOrNaN("Knockback") <= 0.1 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDImpObjects2[k] = gdjs.MainGameCode.GDImpObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDImpObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDImpObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects2[i].addPolarForce((gdjs.RuntimeObject.getVariableNumber(gdjs.MainGameCode.GDImpObjects2[i].getVariables().get("KnockBackAngle"))), 15, 0);
}
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPick_9595UpsObjects3Objects = Hashtable.newFrom({"Pick_Ups": gdjs.MainGameCode.GDPick_95UpsObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPick_9595UpsObjects4Objects = Hashtable.newFrom({"Pick_Ups": gdjs.MainGameCode.GDPick_95UpsObjects4});
gdjs.MainGameCode.eventsList47 = function(runtimeScene) {

};gdjs.MainGameCode.eventsList48 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainGameCode.GDGhostObjects2, gdjs.MainGameCode.GDGhostObjects3);

gdjs.copyArray(gdjs.MainGameCode.GDImpObjects2, gdjs.MainGameCode.GDImpObjects3);

gdjs.copyArray(gdjs.MainGameCode.GDSpiderObjects2, gdjs.MainGameCode.GDSpiderObjects3);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDGhostObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDGhostObjects3[i].getVariableNumber(gdjs.MainGameCode.GDGhostObjects3[i].getVariables().get("DropChance")) <= (gdjs.RuntimeObject.getVariableNumber(gdjs.MainGameCode.GDGhostObjects3[i].getVariables().get("DropChance_HealthOrb"))) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDGhostObjects3[k] = gdjs.MainGameCode.GDGhostObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDGhostObjects3.length = k;for(var i = 0, k = 0, l = gdjs.MainGameCode.GDSpiderObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDSpiderObjects3[i].getVariableNumber(gdjs.MainGameCode.GDSpiderObjects3[i].getVariables().get("DropChance")) <= (gdjs.RuntimeObject.getVariableNumber(gdjs.MainGameCode.GDSpiderObjects3[i].getVariables().get("DropChance_HealthOrb"))) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDSpiderObjects3[k] = gdjs.MainGameCode.GDSpiderObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDSpiderObjects3.length = k;for(var i = 0, k = 0, l = gdjs.MainGameCode.GDImpObjects3.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDImpObjects3[i].getVariableNumber(gdjs.MainGameCode.GDImpObjects3[i].getVariables().get("DropChance")) <= (gdjs.RuntimeObject.getVariableNumber(gdjs.MainGameCode.GDImpObjects3[i].getVariables().get("DropChance_HealthOrb"))) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDImpObjects3[k] = gdjs.MainGameCode.GDImpObjects3[i];
        ++k;
    }
}
gdjs.MainGameCode.GDImpObjects3.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDGhostObjects3 */
/* Reuse gdjs.MainGameCode.GDImpObjects3 */
/* Reuse gdjs.MainGameCode.GDSpiderObjects3 */
gdjs.MainGameCode.GDPick_95UpsObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPick_9595UpsObjects3Objects, (( gdjs.MainGameCode.GDImpObjects3.length === 0 ) ? (( gdjs.MainGameCode.GDSpiderObjects3.length === 0 ) ? (( gdjs.MainGameCode.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDGhostObjects3[0].getPointX("")) :gdjs.MainGameCode.GDSpiderObjects3[0].getPointX("")) :gdjs.MainGameCode.GDImpObjects3[0].getPointX("")), (( gdjs.MainGameCode.GDImpObjects3.length === 0 ) ? (( gdjs.MainGameCode.GDSpiderObjects3.length === 0 ) ? (( gdjs.MainGameCode.GDGhostObjects3.length === 0 ) ? 0 :gdjs.MainGameCode.GDGhostObjects3[0].getPointY("")) :gdjs.MainGameCode.GDSpiderObjects3[0].getPointY("")) :gdjs.MainGameCode.GDImpObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGameCode.GDPick_95UpsObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPick_95UpsObjects3[i].addPolarForce(gdjs.randomFloatInRange(0, 360), 40, 1);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPick_95UpsObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPick_95UpsObjects3[i].setAnimationName("HealthOrb");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPick_95UpsObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDPick_95UpsObjects3[i].setZOrder((gdjs.MainGameCode.GDPick_95UpsObjects3[i].getPointY("")) - 800);
}
}}

}


{

gdjs.copyArray(gdjs.MainGameCode.GDGhostObjects2, gdjs.MainGameCode.GDGhostObjects3);

gdjs.copyArray(gdjs.MainGameCode.GDImpObjects2, gdjs.MainGameCode.GDImpObjects3);

gdjs.copyArray(gdjs.MainGameCode.GDSpiderObjects2, gdjs.MainGameCode.GDSpiderObjects3);


gdjs.MainGameCode.repeatCount4 = (gdjs.RuntimeObject.getVariableNumber(((gdjs.MainGameCode.GDImpObjects3.length === 0 ) ? ((gdjs.MainGameCode.GDSpiderObjects3.length === 0 ) ? ((gdjs.MainGameCode.GDGhostObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.MainGameCode.GDGhostObjects3[0].getVariables()) : gdjs.MainGameCode.GDSpiderObjects3[0].getVariables()) : gdjs.MainGameCode.GDImpObjects3[0].getVariables()).get("DropAmount_Points")));
for(gdjs.MainGameCode.repeatIndex4 = 0;gdjs.MainGameCode.repeatIndex4 < gdjs.MainGameCode.repeatCount4;++gdjs.MainGameCode.repeatIndex4) {
gdjs.copyArray(gdjs.MainGameCode.GDGhostObjects3, gdjs.MainGameCode.GDGhostObjects4);

gdjs.copyArray(gdjs.MainGameCode.GDImpObjects3, gdjs.MainGameCode.GDImpObjects4);

gdjs.copyArray(gdjs.MainGameCode.GDSpiderObjects3, gdjs.MainGameCode.GDSpiderObjects4);

gdjs.MainGameCode.GDPick_95UpsObjects4.length = 0;


if (true)
{
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDPick_9595UpsObjects4Objects, (( gdjs.MainGameCode.GDImpObjects4.length === 0 ) ? (( gdjs.MainGameCode.GDSpiderObjects4.length === 0 ) ? (( gdjs.MainGameCode.GDGhostObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDGhostObjects4[0].getPointX("")) :gdjs.MainGameCode.GDSpiderObjects4[0].getPointX("")) :gdjs.MainGameCode.GDImpObjects4[0].getPointX("")), (( gdjs.MainGameCode.GDImpObjects4.length === 0 ) ? (( gdjs.MainGameCode.GDSpiderObjects4.length === 0 ) ? (( gdjs.MainGameCode.GDGhostObjects4.length === 0 ) ? 0 :gdjs.MainGameCode.GDGhostObjects4[0].getPointY("")) :gdjs.MainGameCode.GDSpiderObjects4[0].getPointY("")) :gdjs.MainGameCode.GDImpObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.MainGameCode.GDPick_95UpsObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDPick_95UpsObjects4[i].addPolarForce(gdjs.randomFloatInRange(0, 360), 50, 1);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDPick_95UpsObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDPick_95UpsObjects4[i].setZOrder((gdjs.MainGameCode.GDPick_95UpsObjects4[i].getPointY("")) - 800);
}
}}
}

}


{


{
/* Reuse gdjs.MainGameCode.GDGhostObjects2 */
/* Reuse gdjs.MainGameCode.GDImpObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Pick_Ups"), gdjs.MainGameCode.GDPick_95UpsObjects2);
/* Reuse gdjs.MainGameCode.GDSpiderObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDPick_95UpsObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPick_95UpsObjects2[i].resetTimer("PickUps");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.MainGameCode.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGameCode.eventsList49 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGameCode.GDImpObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDGhostObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDGhostObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDGhostObjects2[k] = gdjs.MainGameCode.GDGhostObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDGhostObjects2.length = k;for(var i = 0, k = 0, l = gdjs.MainGameCode.GDSpiderObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDSpiderObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDSpiderObjects2[k] = gdjs.MainGameCode.GDSpiderObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDSpiderObjects2.length = k;for(var i = 0, k = 0, l = gdjs.MainGameCode.GDImpObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDImpObjects2[i].getBehavior("Health").IsDead((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDImpObjects2[k] = gdjs.MainGameCode.GDImpObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDImpObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDGhostObjects2 */
/* Reuse gdjs.MainGameCode.GDImpObjects2 */
/* Reuse gdjs.MainGameCode.GDSpiderObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects2[i].returnVariable(gdjs.MainGameCode.GDGhostObjects2[i].getVariables().get("DropChance")).setNumber(gdjs.randomInRange(0, 100));
}
for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects2[i].returnVariable(gdjs.MainGameCode.GDSpiderObjects2[i].getVariables().get("DropChance")).setNumber(gdjs.randomInRange(0, 100));
}
for(var i = 0, len = gdjs.MainGameCode.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects2[i].returnVariable(gdjs.MainGameCode.GDImpObjects2[i].getVariables().get("DropChance")).setNumber(gdjs.randomInRange(0, 100));
}
}
{ //Subevents
gdjs.MainGameCode.eventsList48(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostOrbObjects3Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGameCode.GDGhostOrbObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomObjects3Objects = Hashtable.newFrom({"Room": gdjs.MainGameCode.GDRoomObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostOrbObjects3Objects = Hashtable.newFrom({"GhostOrb": gdjs.MainGameCode.GDGhostOrbObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomDoorsObjects3Objects = Hashtable.newFrom({"RoomDoors": gdjs.MainGameCode.GDRoomDoorsObjects3});
gdjs.MainGameCode.eventsList50 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGameCode.GDImpObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDGhostObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDGhostObjects2[i].getX() < (( gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects2[0].getPointX("")) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDGhostObjects2[k] = gdjs.MainGameCode.GDGhostObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDGhostObjects2.length = k;for(var i = 0, k = 0, l = gdjs.MainGameCode.GDSpiderObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDSpiderObjects2[i].getX() < (( gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects2[0].getPointX("")) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDSpiderObjects2[k] = gdjs.MainGameCode.GDSpiderObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDSpiderObjects2.length = k;for(var i = 0, k = 0, l = gdjs.MainGameCode.GDImpObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDImpObjects2[i].getX() < (( gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects2[0].getPointX("")) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDImpObjects2[k] = gdjs.MainGameCode.GDImpObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDImpObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDGhostObjects2 */
/* Reuse gdjs.MainGameCode.GDImpObjects2 */
/* Reuse gdjs.MainGameCode.GDSpiderObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects2[i].flipX(false);
}
for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects2[i].flipX(false);
}
for(var i = 0, len = gdjs.MainGameCode.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects2[i].flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGameCode.GDImpObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects2);
gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDGhostObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDGhostObjects2[i].getX() > (( gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects2[0].getPointX("")) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDGhostObjects2[k] = gdjs.MainGameCode.GDGhostObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDGhostObjects2.length = k;for(var i = 0, k = 0, l = gdjs.MainGameCode.GDSpiderObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDSpiderObjects2[i].getX() > (( gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects2[0].getPointX("")) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDSpiderObjects2[k] = gdjs.MainGameCode.GDSpiderObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDSpiderObjects2.length = k;for(var i = 0, k = 0, l = gdjs.MainGameCode.GDImpObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDImpObjects2[i].getX() > (( gdjs.MainGameCode.GDWesleyObjects2.length === 0 ) ? 0 :gdjs.MainGameCode.GDWesleyObjects2[0].getPointX("")) ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDImpObjects2[k] = gdjs.MainGameCode.GDImpObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDImpObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDGhostObjects2 */
/* Reuse gdjs.MainGameCode.GDImpObjects2 */
/* Reuse gdjs.MainGameCode.GDSpiderObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects2[i].flipX(true);
}
for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects2[i].flipX(true);
}
for(var i = 0, len = gdjs.MainGameCode.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects2[i].flipX(true);
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGameCode.GDImpObjects2);
gdjs.copyArray(runtimeScene.getObjects("Room"), gdjs.MainGameCode.GDRoomObjects2);
gdjs.copyArray(runtimeScene.getObjects("RoomTraps"), gdjs.MainGameCode.GDRoomTrapsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects2);
{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects2[i].separateFromObjectsList(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomObjects2Objects, false);
}
for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects2[i].separateFromObjectsList(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomObjects2Objects, false);
}
for(var i = 0, len = gdjs.MainGameCode.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects2[i].separateFromObjectsList(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomObjects2Objects, false);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects2[i].separateFromObjectsList(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomTrapsObjects2Objects, false);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects2[i].separateFromObjectsList(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomTrapsObjects2Objects, false);
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Ghost"), gdjs.MainGameCode.GDGhostObjects2);
gdjs.copyArray(runtimeScene.getObjects("Imp"), gdjs.MainGameCode.GDImpObjects2);
gdjs.copyArray(runtimeScene.getObjects("Spider"), gdjs.MainGameCode.GDSpiderObjects2);
{for(var i = 0, len = gdjs.MainGameCode.GDGhostObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostObjects2[i].separateFromObjectsList(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostObjects2Objects, false);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDSpiderObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDSpiderObjects2[i].separateFromObjectsList(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDSpiderObjects2Objects, false);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDImpObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDImpObjects2[i].separateFromObjectsList(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDImpObjects2Objects, false);
}
}}

}


{


gdjs.MainGameCode.eventsList40(runtimeScene);
}


{


gdjs.MainGameCode.eventsList43(runtimeScene);
}


{


gdjs.MainGameCode.eventsList46(runtimeScene);
}


{


gdjs.MainGameCode.eventsList49(runtimeScene);
}


{



}


{

gdjs.MainGameCode.GDGhostOrbObjects2.length = 0;

gdjs.MainGameCode.GDRoomObjects2.length = 0;

gdjs.MainGameCode.GDRoomDoorsObjects2.length = 0;


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.GDGhostOrbObjects2_1final.length = 0;gdjs.MainGameCode.GDRoomObjects2_1final.length = 0;gdjs.MainGameCode.GDRoomDoorsObjects2_1final.length = 0;gdjs.MainGameCode.condition0IsTrue_1.val = false;
gdjs.MainGameCode.condition1IsTrue_1.val = false;
{
gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGameCode.GDGhostOrbObjects3);
gdjs.copyArray(runtimeScene.getObjects("Room"), gdjs.MainGameCode.GDRoomObjects3);
gdjs.MainGameCode.condition0IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostOrbObjects3Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomObjects3Objects, false, runtimeScene, false);
if( gdjs.MainGameCode.condition0IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDGhostOrbObjects3.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDGhostOrbObjects2_1final.indexOf(gdjs.MainGameCode.GDGhostOrbObjects3[j]) === -1 )
            gdjs.MainGameCode.GDGhostOrbObjects2_1final.push(gdjs.MainGameCode.GDGhostOrbObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomObjects3.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomObjects2_1final.indexOf(gdjs.MainGameCode.GDRoomObjects3[j]) === -1 )
            gdjs.MainGameCode.GDRoomObjects2_1final.push(gdjs.MainGameCode.GDRoomObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("GhostOrb"), gdjs.MainGameCode.GDGhostOrbObjects3);
gdjs.copyArray(runtimeScene.getObjects("RoomDoors"), gdjs.MainGameCode.GDRoomDoorsObjects3);
gdjs.MainGameCode.condition1IsTrue_1.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDGhostOrbObjects3Objects, gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDRoomDoorsObjects3Objects, false, runtimeScene, false);
if( gdjs.MainGameCode.condition1IsTrue_1.val ) {
    gdjs.MainGameCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.MainGameCode.GDGhostOrbObjects3.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDGhostOrbObjects2_1final.indexOf(gdjs.MainGameCode.GDGhostOrbObjects3[j]) === -1 )
            gdjs.MainGameCode.GDGhostOrbObjects2_1final.push(gdjs.MainGameCode.GDGhostOrbObjects3[j]);
    }
    for(var j = 0, jLen = gdjs.MainGameCode.GDRoomDoorsObjects3.length;j<jLen;++j) {
        if ( gdjs.MainGameCode.GDRoomDoorsObjects2_1final.indexOf(gdjs.MainGameCode.GDRoomDoorsObjects3[j]) === -1 )
            gdjs.MainGameCode.GDRoomDoorsObjects2_1final.push(gdjs.MainGameCode.GDRoomDoorsObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.MainGameCode.GDGhostOrbObjects2_1final, gdjs.MainGameCode.GDGhostOrbObjects2);
gdjs.copyArray(gdjs.MainGameCode.GDRoomObjects2_1final, gdjs.MainGameCode.GDRoomObjects2);
gdjs.copyArray(gdjs.MainGameCode.GDRoomDoorsObjects2_1final, gdjs.MainGameCode.GDRoomDoorsObjects2);
}
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDGhostOrbObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDGhostOrbObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDGhostOrbObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Pick_Ups"), gdjs.MainGameCode.GDPick_95UpsObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPick_95UpsObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPick_95UpsObjects2[i].getTimerElapsedTimeInSecondsOrNaN("PickUps") > 0.2 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPick_95UpsObjects2[k] = gdjs.MainGameCode.GDPick_95UpsObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPick_95UpsObjects2.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition1IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11889404);
}
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPick_95UpsObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDPick_95UpsObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDPick_95UpsObjects2[i].clearForces();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Pick_Ups"), gdjs.MainGameCode.GDPick_95UpsObjects1);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDPick_95UpsObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDPick_95UpsObjects1[i].getTimerElapsedTimeInSecondsOrNaN("PickUps") > 5 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDPick_95UpsObjects1[k] = gdjs.MainGameCode.GDPick_95UpsObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDPick_95UpsObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDPick_95UpsObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDPick_95UpsObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDPick_95UpsObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGameCode.eventsList51 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("EnemyDamageText"), gdjs.MainGameCode.GDEnemyDamageTextObjects2);
{for(var i = 0, len = gdjs.MainGameCode.GDEnemyDamageTextObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDEnemyDamageTextObjects2[i].setOpacity(gdjs.MainGameCode.GDEnemyDamageTextObjects2[i].getOpacity() - (150 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("EnemyDamageText"), gdjs.MainGameCode.GDEnemyDamageTextObjects1);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDEnemyDamageTextObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDEnemyDamageTextObjects1[i].getOpacity() <= 0 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDEnemyDamageTextObjects1[k] = gdjs.MainGameCode.GDEnemyDamageTextObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDEnemyDamageTextObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDEnemyDamageTextObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDEnemyDamageTextObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDEnemyDamageTextObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects1Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects1});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDReset_9595ButtonObjects2Objects = Hashtable.newFrom({"Reset_Button": gdjs.MainGameCode.GDReset_95ButtonObjects2});
gdjs.MainGameCode.eventsList52 = function(runtimeScene) {

{

/* Reuse gdjs.MainGameCode.GDReset_95ButtonObjects2 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDReset_9595ButtonObjects2Objects) == 1;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "MenuButtomPress.wav", false, 60, 0.8);
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDReset_9595ButtonObjects3Objects = Hashtable.newFrom({"Reset_Button": gdjs.MainGameCode.GDReset_95ButtonObjects3});
gdjs.MainGameCode.eventsList53 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11900948);
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDReset_95ButtonObjects3, gdjs.MainGameCode.GDReset_95ButtonObjects4);

{for(var i = 0, len = gdjs.MainGameCode.GDReset_95ButtonObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95ButtonObjects4[i].setColor("255;235;0");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition1IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11901756);
}
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDReset_95ButtonObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Reset_Leaderboard"), gdjs.MainGameCode.GDReset_95LeaderboardObjects3);
{for(var i = 0, len = gdjs.MainGameCode.GDReset_95ButtonObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95ButtonObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDReset_95LeaderboardObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95LeaderboardObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Death");
}{gdjs.evtTools.sound.playSound(runtimeScene, "MenuButtomPress.wav", false, 30, 1);
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDReset_9595ButtonObjects3Objects = Hashtable.newFrom({"Reset_Button": gdjs.MainGameCode.GDReset_95ButtonObjects3});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDReset_9595ButtonObjects3Objects = Hashtable.newFrom({"Reset_Button": gdjs.MainGameCode.GDReset_95ButtonObjects3});
gdjs.MainGameCode.asyncCallback11908132 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainGame", false);
}}
gdjs.MainGameCode.eventsList54 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainGameCode.asyncCallback11908132(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainGameCode.asyncCallback11906988 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Reset_Timer"), gdjs.MainGameCode.GDReset_95TimerObjects5);

{for(var i = 0, len = gdjs.MainGameCode.GDReset_95TimerObjects5.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95TimerObjects5[i].setString("1");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDReset_95TimerObjects5.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95TimerObjects5[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGameCode.GDReset_95TimerObjects5[i].getWidth()) / 2));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ResetTimer.wav", false, 50, 1.2);
}{for(var i = 0, len = gdjs.MainGameCode.GDReset_95TimerObjects5.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95TimerObjects5[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 7, 7, 7, 0.08, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MainGameCode.eventsList54(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.MainGameCode.eventsList55 = function(runtimeScene, asyncObjectsList) {

{


{
const parentAsyncObjectsList = asyncObjectsList;
{
const asyncObjectsList = gdjs.LongLivedObjectsList.from(parentAsyncObjectsList);
for (const obj of gdjs.MainGameCode.GDReset_95TimerObjects4) asyncObjectsList.addObject("Reset_Timer", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainGameCode.asyncCallback11906988(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainGameCode.asyncCallback11905932 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Reset_Timer"), gdjs.MainGameCode.GDReset_95TimerObjects4);

{for(var i = 0, len = gdjs.MainGameCode.GDReset_95TimerObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95TimerObjects4[i].setString("2");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDReset_95TimerObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95TimerObjects4[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGameCode.GDReset_95TimerObjects4[i].getWidth()) / 2));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ResetTimer.wav", false, 40, 1);
}{for(var i = 0, len = gdjs.MainGameCode.GDReset_95TimerObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95TimerObjects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 4, 4, 4, 0.08, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MainGameCode.eventsList55(runtimeScene, asyncObjectsList);} //End of subevents
}
gdjs.MainGameCode.eventsList56 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.MainGameCode.GDReset_95TimerObjects3) asyncObjectsList.addObject("Reset_Timer", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.MainGameCode.asyncCallback11905932(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.MainGameCode.eventsList57 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11904452);
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Reset_Timer"), gdjs.MainGameCode.GDReset_95TimerObjects3);
{for(var i = 0, len = gdjs.MainGameCode.GDReset_95TimerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95TimerObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDReset_95TimerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95TimerObjects3[i].setString("3");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDReset_95TimerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95TimerObjects3[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGameCode.GDReset_95TimerObjects3[i].getWidth()) / 2));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "ResetTimer.wav", false, 30, 0.8);
}{for(var i = 0, len = gdjs.MainGameCode.GDReset_95TimerObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95TimerObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2, 2, 2, 0.08, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}
{ //Subevents
gdjs.MainGameCode.eventsList56(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDReset_9595LeaderboardObjects3Objects = Hashtable.newFrom({"Reset_Leaderboard": gdjs.MainGameCode.GDReset_95LeaderboardObjects3});
gdjs.MainGameCode.eventsList58 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11909844);
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDReset_95LeaderboardObjects3, gdjs.MainGameCode.GDReset_95LeaderboardObjects4);

{for(var i = 0, len = gdjs.MainGameCode.GDReset_95LeaderboardObjects4.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95LeaderboardObjects4[i].setColor("255;235;0");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition1IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11909692);
}
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LeaderboardName_Input"), gdjs.MainGameCode.GDLeaderboardName_95InputObjects3);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard_Submit"), gdjs.MainGameCode.GDLeaderboard_95SubmitObjects3);
gdjs.copyArray(runtimeScene.getObjects("Reset_Button"), gdjs.MainGameCode.GDReset_95ButtonObjects3);
/* Reuse gdjs.MainGameCode.GDReset_95LeaderboardObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDReset_95LeaderboardObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95LeaderboardObjects3[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.MainGameCode.GDReset_95ButtonObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95ButtonObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.camera.showLayer(runtimeScene, "Leaderboard");
}{for(var i = 0, len = gdjs.MainGameCode.GDLeaderboardName_95InputObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDLeaderboardName_95InputObjects3[i].setPlaceholder("Add Name");
}
}{for(var i = 0, len = gdjs.MainGameCode.GDLeaderboard_95SubmitObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDLeaderboard_95SubmitObjects3[i].hide();
}
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDReset_9595LeaderboardObjects2Objects = Hashtable.newFrom({"Reset_Leaderboard": gdjs.MainGameCode.GDReset_95LeaderboardObjects2});
gdjs.MainGameCode.eventsList59 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Reset_Button"), gdjs.MainGameCode.GDReset_95ButtonObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDReset_9595ButtonObjects3Objects, runtimeScene, true, false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList53(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Reset_Button"), gdjs.MainGameCode.GDReset_95ButtonObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDReset_9595ButtonObjects3Objects, runtimeScene, true, true);
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition1IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11903116);
}
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDReset_95ButtonObjects3 */
{for(var i = 0, len = gdjs.MainGameCode.GDReset_95ButtonObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95ButtonObjects3[i].setColor("255;255;255");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Reset_Button"), gdjs.MainGameCode.GDReset_95ButtonObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDReset_9595ButtonObjects3Objects) == 0;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList57(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Reset_Leaderboard"), gdjs.MainGameCode.GDReset_95LeaderboardObjects3);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDReset_9595LeaderboardObjects3Objects, runtimeScene, true, false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList58(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Reset_Leaderboard"), gdjs.MainGameCode.GDReset_95LeaderboardObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDReset_9595LeaderboardObjects2Objects, runtimeScene, true, true);
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition1IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11911980);
}
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDReset_95LeaderboardObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDReset_95LeaderboardObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95LeaderboardObjects2[i].setColor("255;255;255");
}
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDLeaderboard_9595SubmitObjects2Objects = Hashtable.newFrom({"Leaderboard_Submit": gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2});
gdjs.MainGameCode.eventsList60 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11916524);
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2, gdjs.MainGameCode.GDLeaderboard_95SubmitObjects3);

{for(var i = 0, len = gdjs.MainGameCode.GDLeaderboard_95SubmitObjects3.length ;i < len;++i) {
    gdjs.MainGameCode.GDLeaderboard_95SubmitObjects3[i].setColor("255;235;0");
}
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition1IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11917172);
}
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LeaderboardName_Input"), gdjs.MainGameCode.GDLeaderboardName_95InputObjects2);
{gdjs.evtTools.leaderboards.savePlayerScore(runtimeScene, "9f08aecb-b8e6-4331-b9cc-da1e7bdb20fa", gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)), (( gdjs.MainGameCode.GDLeaderboardName_95InputObjects2.length === 0 ) ? "" :gdjs.MainGameCode.GDLeaderboardName_95InputObjects2[0].getString()));
}{gdjs.evtTools.leaderboards.displayLeaderboard(runtimeScene, "9f08aecb-b8e6-4331-b9cc-da1e7bdb20fa", true);
}}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDLeaderboard_9595SubmitObjects2Objects = Hashtable.newFrom({"Leaderboard_Submit": gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2});
gdjs.MainGameCode.eventsList61 = function(runtimeScene) {

{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11913444);
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("LeaderboardName_Input"), gdjs.MainGameCode.GDLeaderboardName_95InputObjects2);
gdjs.copyArray(runtimeScene.getObjects("Leaderboard_Submit"), gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2);
{gdjs.evtTools.sound.playSound(runtimeScene, "MenuButtomPress.wav", false, 60, 0.8);
}{for(var i = 0, len = gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2[i].getWidth()) / 2));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDLeaderboardName_95InputObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDLeaderboardName_95InputObjects2[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGameCode.GDLeaderboardName_95InputObjects2[i].getWidth()) / 2));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("LeaderboardName_Input"), gdjs.MainGameCode.GDLeaderboardName_95InputObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDLeaderboardName_95InputObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDLeaderboardName_95InputObjects2[i].isFocused() ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDLeaderboardName_95InputObjects2[k] = gdjs.MainGameCode.GDLeaderboardName_95InputObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDLeaderboardName_95InputObjects2.length = k;}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDLeaderboardName_95InputObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDLeaderboardName_95InputObjects2[i].getString() != "" ) {
        gdjs.MainGameCode.condition1IsTrue_0.val = true;
        gdjs.MainGameCode.GDLeaderboardName_95InputObjects2[k] = gdjs.MainGameCode.GDLeaderboardName_95InputObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDLeaderboardName_95InputObjects2.length = k;}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Leaderboard_Submit"), gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2);
{for(var i = 0, len = gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2[i].hide(false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Leaderboard_Submit"), gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDLeaderboard_9595SubmitObjects2Objects, runtimeScene, true, false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList60(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Leaderboard_Submit"), gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDLeaderboard_9595SubmitObjects2Objects, runtimeScene, true, true);
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition1IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11918892);
}
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2 */
{for(var i = 0, len = gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2[i].setColor("255;255;255");
}
}}

}


{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.leaderboards.isLeaderboardViewLoaded();
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Death");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "Leaderboard");
}{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "Leaderboard");
}}

}


};gdjs.MainGameCode.eventsList62 = function(runtimeScene) {

{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition0IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11895060);
}
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Death");
}}

}


{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Death") > 1.5;
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition1IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11895948);
}
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Darkening"), gdjs.MainGameCode.GDDarkeningObjects2);
gdjs.copyArray(runtimeScene.getObjects("Reset_Button"), gdjs.MainGameCode.GDReset_95ButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("Reset_Leaderboard"), gdjs.MainGameCode.GDReset_95LeaderboardObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "Reset");
}{for(var i = 0, len = gdjs.MainGameCode.GDReset_95ButtonObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95ButtonObjects2[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGameCode.GDReset_95ButtonObjects2[i].getWidth()) / 2));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDReset_95LeaderboardObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95LeaderboardObjects2[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.MainGameCode.GDReset_95LeaderboardObjects2[i].getWidth()) / 2));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDReset_95ButtonObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95ButtonObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2, 2, 3, 0.2, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDReset_95LeaderboardObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95LeaderboardObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.5, 2, 2, 3, 0.2, true, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.MainGameCode.GDDarkeningObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDDarkeningObjects2[i].setOpacity(100);
}
}
{ //Subevents
gdjs.MainGameCode.eventsList52(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Reset");
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
gdjs.MainGameCode.condition1IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Leaderboard"));
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList59(runtimeScene);} //End of subevents
}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "Leaderboard");
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList61(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.eventsList63 = function(runtimeScene) {

{



}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Reset_Timer"), gdjs.MainGameCode.GDReset_95TimerObjects2);
{for(var i = 0, len = gdjs.MainGameCode.GDReset_95TimerObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDReset_95TimerObjects2[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects1);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects1Objects) <= 0;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList62(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects2Objects = Hashtable.newFrom({"Wesley": gdjs.MainGameCode.GDWesleyObjects2});
gdjs.MainGameCode.eventsList64 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("PauseGameToggle"), true);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "PauseLayer");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getGame().getVariables().get("PauseGameToggle"), false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "PauseLayer");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}}

}


};gdjs.MainGameCode.eventsList65 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
gdjs.MainGameCode.condition1IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if ( gdjs.MainGameCode.condition0IsTrue_0.val ) {
{
{gdjs.MainGameCode.conditionTrue_1 = gdjs.MainGameCode.condition1IsTrue_0;
gdjs.MainGameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11922716);
}
}}
if (gdjs.MainGameCode.condition1IsTrue_0.val) {
{gdjs.evtTools.variable.toggleVariableBoolean(runtimeScene.getGame().getVariables().get("PauseGameToggle"));
}
{ //Subevents
gdjs.MainGameCode.eventsList64(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.eventsList66 = function(runtimeScene) {

{

/* Reuse gdjs.MainGameCode.GDWesleyObjects2 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDWesleyObjects2Objects) > 0;
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList65(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradeIconsObjects2Objects = Hashtable.newFrom({"UpgradeIcons": gdjs.MainGameCode.GDUpgradeIconsObjects2});
gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradeIconsObjects1Objects = Hashtable.newFrom({"UpgradeIcons": gdjs.MainGameCode.GDUpgradeIconsObjects1});
gdjs.MainGameCode.eventsList67 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.MainGameCode.GDUpgradeIconsObjects1, gdjs.MainGameCode.GDUpgradeIconsObjects2);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDUpgradeIconsObjects2[i].isCurrentAnimationName("HealthUp") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDUpgradeIconsObjects2[k] = gdjs.MainGameCode.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDUpgradeIconsObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDUpgrade_95TextObjects1, gdjs.MainGameCode.GDUpgrade_95TextObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDUpgrade_95TextObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgrade_95TextObjects2[i].setString("+Max Health");
}
}}

}


{

gdjs.copyArray(gdjs.MainGameCode.GDUpgradeIconsObjects1, gdjs.MainGameCode.GDUpgradeIconsObjects2);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDUpgradeIconsObjects2[i].isCurrentAnimationName("FireRate") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDUpgradeIconsObjects2[k] = gdjs.MainGameCode.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDUpgradeIconsObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDUpgrade_95TextObjects1, gdjs.MainGameCode.GDUpgrade_95TextObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDUpgrade_95TextObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgrade_95TextObjects2[i].setString("+Fire Rate");
}
}}

}


{

gdjs.copyArray(gdjs.MainGameCode.GDUpgradeIconsObjects1, gdjs.MainGameCode.GDUpgradeIconsObjects2);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDUpgradeIconsObjects2[i].isCurrentAnimationName("Armor") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDUpgradeIconsObjects2[k] = gdjs.MainGameCode.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDUpgradeIconsObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDUpgrade_95TextObjects1, gdjs.MainGameCode.GDUpgrade_95TextObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDUpgrade_95TextObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgrade_95TextObjects2[i].setString("+Defense");
}
}}

}


{

gdjs.copyArray(gdjs.MainGameCode.GDUpgradeIconsObjects1, gdjs.MainGameCode.GDUpgradeIconsObjects2);


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDUpgradeIconsObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDUpgradeIconsObjects2[i].isCurrentAnimationName("Power") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDUpgradeIconsObjects2[k] = gdjs.MainGameCode.GDUpgradeIconsObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDUpgradeIconsObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDUpgrade_95TextObjects1, gdjs.MainGameCode.GDUpgrade_95TextObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDUpgrade_95TextObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgrade_95TextObjects2[i].setString("+Attack Power");
}
}}

}


{

/* Reuse gdjs.MainGameCode.GDUpgradeIconsObjects1 */

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDUpgradeIconsObjects1.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDUpgradeIconsObjects1[i].isCurrentAnimationName("Speed") ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDUpgradeIconsObjects1[k] = gdjs.MainGameCode.GDUpgradeIconsObjects1[i];
        ++k;
    }
}
gdjs.MainGameCode.GDUpgradeIconsObjects1.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MainGameCode.GDUpgrade_95TextObjects1 */
{for(var i = 0, len = gdjs.MainGameCode.GDUpgrade_95TextObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgrade_95TextObjects1[i].setString("+Move Speed");
}
}}

}


};gdjs.MainGameCode.eventsList68 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("UpgradeIcons"), gdjs.MainGameCode.GDUpgradeIconsObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradeIconsObjects2Objects, runtimeScene, true, true);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(gdjs.MainGameCode.GDUpgrade_95TextObjects1, gdjs.MainGameCode.GDUpgrade_95TextObjects2);

{for(var i = 0, len = gdjs.MainGameCode.GDUpgrade_95TextObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgrade_95TextObjects2[i].setString(" ");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("UpgradeIcons"), gdjs.MainGameCode.GDUpgradeIconsObjects1);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MainGameCode.mapOfGDgdjs_46MainGameCode_46GDUpgradeIconsObjects1Objects, runtimeScene, true, false);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList67(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.eventsList69 = function(runtimeScene) {

{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Darkening"), gdjs.MainGameCode.GDDarkeningObjects2);
{for(var i = 0, len = gdjs.MainGameCode.GDDarkeningObjects2.length ;i < len;++i) {
    gdjs.MainGameCode.GDDarkeningObjects2[i].setOpacity(100);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Wesley"), gdjs.MainGameCode.GDWesleyObjects2);

gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.MainGameCode.GDWesleyObjects2.length;i<l;++i) {
    if ( gdjs.MainGameCode.GDWesleyObjects2[i].getVariableNumber(gdjs.MainGameCode.GDWesleyObjects2[i].getVariables().getFromIndex(4)) == 0 ) {
        gdjs.MainGameCode.condition0IsTrue_0.val = true;
        gdjs.MainGameCode.GDWesleyObjects2[k] = gdjs.MainGameCode.GDWesleyObjects2[i];
        ++k;
    }
}
gdjs.MainGameCode.GDWesleyObjects2.length = k;}if (gdjs.MainGameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.MainGameCode.eventsList66(runtimeScene);} //End of subevents
}

}


{


gdjs.MainGameCode.condition0IsTrue_0.val = false;
{
gdjs.MainGameCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "PauseLayer");
}if (gdjs.MainGameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Upgrade_Text"), gdjs.MainGameCode.GDUpgrade_95TextObjects1);
{for(var i = 0, len = gdjs.MainGameCode.GDUpgrade_95TextObjects1.length ;i < len;++i) {
    gdjs.MainGameCode.GDUpgrade_95TextObjects1[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "PauseLayer", 0) + 10,gdjs.evtTools.input.getMouseY(runtimeScene, "PauseLayer", 0) + 10);
}
}
{ //Subevents
gdjs.MainGameCode.eventsList68(runtimeScene);} //End of subevents
}

}


};gdjs.MainGameCode.eventsList70 = function(runtimeScene) {

{


gdjs.MainGameCode.eventsList2(runtimeScene);
}


{


gdjs.MainGameCode.eventsList5(runtimeScene);
}


{


gdjs.MainGameCode.eventsList15(runtimeScene);
}


{


gdjs.MainGameCode.eventsList19(runtimeScene);
}


{


gdjs.MainGameCode.eventsList39(runtimeScene);
}


{


gdjs.MainGameCode.eventsList50(runtimeScene);
}


{


gdjs.MainGameCode.eventsList51(runtimeScene);
}


{


gdjs.MainGameCode.eventsList63(runtimeScene);
}


{


gdjs.MainGameCode.eventsList69(runtimeScene);
}


};

gdjs.MainGameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MainGameCode.GDRoomTrapsObjects1.length = 0;
gdjs.MainGameCode.GDRoomTrapsObjects2.length = 0;
gdjs.MainGameCode.GDRoomTrapsObjects3.length = 0;
gdjs.MainGameCode.GDRoomTrapsObjects4.length = 0;
gdjs.MainGameCode.GDRoomTrapsObjects5.length = 0;
gdjs.MainGameCode.GDRoomTrapsObjects6.length = 0;
gdjs.MainGameCode.GDRoomDoorsObjects1.length = 0;
gdjs.MainGameCode.GDRoomDoorsObjects2.length = 0;
gdjs.MainGameCode.GDRoomDoorsObjects3.length = 0;
gdjs.MainGameCode.GDRoomDoorsObjects4.length = 0;
gdjs.MainGameCode.GDRoomDoorsObjects5.length = 0;
gdjs.MainGameCode.GDRoomDoorsObjects6.length = 0;
gdjs.MainGameCode.GDRoomFloorObjects1.length = 0;
gdjs.MainGameCode.GDRoomFloorObjects2.length = 0;
gdjs.MainGameCode.GDRoomFloorObjects3.length = 0;
gdjs.MainGameCode.GDRoomFloorObjects4.length = 0;
gdjs.MainGameCode.GDRoomFloorObjects5.length = 0;
gdjs.MainGameCode.GDRoomFloorObjects6.length = 0;
gdjs.MainGameCode.GDRoomObjects1.length = 0;
gdjs.MainGameCode.GDRoomObjects2.length = 0;
gdjs.MainGameCode.GDRoomObjects3.length = 0;
gdjs.MainGameCode.GDRoomObjects4.length = 0;
gdjs.MainGameCode.GDRoomObjects5.length = 0;
gdjs.MainGameCode.GDRoomObjects6.length = 0;
gdjs.MainGameCode.GDWesleyObjects1.length = 0;
gdjs.MainGameCode.GDWesleyObjects2.length = 0;
gdjs.MainGameCode.GDWesleyObjects3.length = 0;
gdjs.MainGameCode.GDWesleyObjects4.length = 0;
gdjs.MainGameCode.GDWesleyObjects5.length = 0;
gdjs.MainGameCode.GDWesleyObjects6.length = 0;
gdjs.MainGameCode.GDGunObjects1.length = 0;
gdjs.MainGameCode.GDGunObjects2.length = 0;
gdjs.MainGameCode.GDGunObjects3.length = 0;
gdjs.MainGameCode.GDGunObjects4.length = 0;
gdjs.MainGameCode.GDGunObjects5.length = 0;
gdjs.MainGameCode.GDGunObjects6.length = 0;
gdjs.MainGameCode.GDImpObjects1.length = 0;
gdjs.MainGameCode.GDImpObjects2.length = 0;
gdjs.MainGameCode.GDImpObjects3.length = 0;
gdjs.MainGameCode.GDImpObjects4.length = 0;
gdjs.MainGameCode.GDImpObjects5.length = 0;
gdjs.MainGameCode.GDImpObjects6.length = 0;
gdjs.MainGameCode.GDSpiderObjects1.length = 0;
gdjs.MainGameCode.GDSpiderObjects2.length = 0;
gdjs.MainGameCode.GDSpiderObjects3.length = 0;
gdjs.MainGameCode.GDSpiderObjects4.length = 0;
gdjs.MainGameCode.GDSpiderObjects5.length = 0;
gdjs.MainGameCode.GDSpiderObjects6.length = 0;
gdjs.MainGameCode.GDGhostObjects1.length = 0;
gdjs.MainGameCode.GDGhostObjects2.length = 0;
gdjs.MainGameCode.GDGhostObjects3.length = 0;
gdjs.MainGameCode.GDGhostObjects4.length = 0;
gdjs.MainGameCode.GDGhostObjects5.length = 0;
gdjs.MainGameCode.GDGhostObjects6.length = 0;
gdjs.MainGameCode.GDGhostOrbObjects1.length = 0;
gdjs.MainGameCode.GDGhostOrbObjects2.length = 0;
gdjs.MainGameCode.GDGhostOrbObjects3.length = 0;
gdjs.MainGameCode.GDGhostOrbObjects4.length = 0;
gdjs.MainGameCode.GDGhostOrbObjects5.length = 0;
gdjs.MainGameCode.GDGhostOrbObjects6.length = 0;
gdjs.MainGameCode.GDBulletObjects1.length = 0;
gdjs.MainGameCode.GDBulletObjects2.length = 0;
gdjs.MainGameCode.GDBulletObjects3.length = 0;
gdjs.MainGameCode.GDBulletObjects4.length = 0;
gdjs.MainGameCode.GDBulletObjects5.length = 0;
gdjs.MainGameCode.GDBulletObjects6.length = 0;
gdjs.MainGameCode.GDUpgradeTextObjects1.length = 0;
gdjs.MainGameCode.GDUpgradeTextObjects2.length = 0;
gdjs.MainGameCode.GDUpgradeTextObjects3.length = 0;
gdjs.MainGameCode.GDUpgradeTextObjects4.length = 0;
gdjs.MainGameCode.GDUpgradeTextObjects5.length = 0;
gdjs.MainGameCode.GDUpgradeTextObjects6.length = 0;
gdjs.MainGameCode.GDEnemyDamageTextObjects1.length = 0;
gdjs.MainGameCode.GDEnemyDamageTextObjects2.length = 0;
gdjs.MainGameCode.GDEnemyDamageTextObjects3.length = 0;
gdjs.MainGameCode.GDEnemyDamageTextObjects4.length = 0;
gdjs.MainGameCode.GDEnemyDamageTextObjects5.length = 0;
gdjs.MainGameCode.GDEnemyDamageTextObjects6.length = 0;
gdjs.MainGameCode.GDParticle_95RecoilDustObjects1.length = 0;
gdjs.MainGameCode.GDParticle_95RecoilDustObjects2.length = 0;
gdjs.MainGameCode.GDParticle_95RecoilDustObjects3.length = 0;
gdjs.MainGameCode.GDParticle_95RecoilDustObjects4.length = 0;
gdjs.MainGameCode.GDParticle_95RecoilDustObjects5.length = 0;
gdjs.MainGameCode.GDParticle_95RecoilDustObjects6.length = 0;
gdjs.MainGameCode.GDParticle_95DashObjects1.length = 0;
gdjs.MainGameCode.GDParticle_95DashObjects2.length = 0;
gdjs.MainGameCode.GDParticle_95DashObjects3.length = 0;
gdjs.MainGameCode.GDParticle_95DashObjects4.length = 0;
gdjs.MainGameCode.GDParticle_95DashObjects5.length = 0;
gdjs.MainGameCode.GDParticle_95DashObjects6.length = 0;
gdjs.MainGameCode.GDParticle_95DeathObjects1.length = 0;
gdjs.MainGameCode.GDParticle_95DeathObjects2.length = 0;
gdjs.MainGameCode.GDParticle_95DeathObjects3.length = 0;
gdjs.MainGameCode.GDParticle_95DeathObjects4.length = 0;
gdjs.MainGameCode.GDParticle_95DeathObjects5.length = 0;
gdjs.MainGameCode.GDParticle_95DeathObjects6.length = 0;
gdjs.MainGameCode.GDHealthBarBorderObjects1.length = 0;
gdjs.MainGameCode.GDHealthBarBorderObjects2.length = 0;
gdjs.MainGameCode.GDHealthBarBorderObjects3.length = 0;
gdjs.MainGameCode.GDHealthBarBorderObjects4.length = 0;
gdjs.MainGameCode.GDHealthBarBorderObjects5.length = 0;
gdjs.MainGameCode.GDHealthBarBorderObjects6.length = 0;
gdjs.MainGameCode.GDHealthBarObjects1.length = 0;
gdjs.MainGameCode.GDHealthBarObjects2.length = 0;
gdjs.MainGameCode.GDHealthBarObjects3.length = 0;
gdjs.MainGameCode.GDHealthBarObjects4.length = 0;
gdjs.MainGameCode.GDHealthBarObjects5.length = 0;
gdjs.MainGameCode.GDHealthBarObjects6.length = 0;
gdjs.MainGameCode.GDDebugObjects1.length = 0;
gdjs.MainGameCode.GDDebugObjects2.length = 0;
gdjs.MainGameCode.GDDebugObjects3.length = 0;
gdjs.MainGameCode.GDDebugObjects4.length = 0;
gdjs.MainGameCode.GDDebugObjects5.length = 0;
gdjs.MainGameCode.GDDebugObjects6.length = 0;
gdjs.MainGameCode.GDUpgradeIconsObjects1.length = 0;
gdjs.MainGameCode.GDUpgradeIconsObjects2.length = 0;
gdjs.MainGameCode.GDUpgradeIconsObjects3.length = 0;
gdjs.MainGameCode.GDUpgradeIconsObjects4.length = 0;
gdjs.MainGameCode.GDUpgradeIconsObjects5.length = 0;
gdjs.MainGameCode.GDUpgradeIconsObjects6.length = 0;
gdjs.MainGameCode.GDUpgradesObjects1.length = 0;
gdjs.MainGameCode.GDUpgradesObjects2.length = 0;
gdjs.MainGameCode.GDUpgradesObjects3.length = 0;
gdjs.MainGameCode.GDUpgradesObjects4.length = 0;
gdjs.MainGameCode.GDUpgradesObjects5.length = 0;
gdjs.MainGameCode.GDUpgradesObjects6.length = 0;
gdjs.MainGameCode.GDTotalPointsCountObjects1.length = 0;
gdjs.MainGameCode.GDTotalPointsCountObjects2.length = 0;
gdjs.MainGameCode.GDTotalPointsCountObjects3.length = 0;
gdjs.MainGameCode.GDTotalPointsCountObjects4.length = 0;
gdjs.MainGameCode.GDTotalPointsCountObjects5.length = 0;
gdjs.MainGameCode.GDTotalPointsCountObjects6.length = 0;
gdjs.MainGameCode.GDTotalPointsObjects1.length = 0;
gdjs.MainGameCode.GDTotalPointsObjects2.length = 0;
gdjs.MainGameCode.GDTotalPointsObjects3.length = 0;
gdjs.MainGameCode.GDTotalPointsObjects4.length = 0;
gdjs.MainGameCode.GDTotalPointsObjects5.length = 0;
gdjs.MainGameCode.GDTotalPointsObjects6.length = 0;
gdjs.MainGameCode.GDDangerLevelCountObjects1.length = 0;
gdjs.MainGameCode.GDDangerLevelCountObjects2.length = 0;
gdjs.MainGameCode.GDDangerLevelCountObjects3.length = 0;
gdjs.MainGameCode.GDDangerLevelCountObjects4.length = 0;
gdjs.MainGameCode.GDDangerLevelCountObjects5.length = 0;
gdjs.MainGameCode.GDDangerLevelCountObjects6.length = 0;
gdjs.MainGameCode.GDDangerLevelObjects1.length = 0;
gdjs.MainGameCode.GDDangerLevelObjects2.length = 0;
gdjs.MainGameCode.GDDangerLevelObjects3.length = 0;
gdjs.MainGameCode.GDDangerLevelObjects4.length = 0;
gdjs.MainGameCode.GDDangerLevelObjects5.length = 0;
gdjs.MainGameCode.GDDangerLevelObjects6.length = 0;
gdjs.MainGameCode.GDHealthTextObjects1.length = 0;
gdjs.MainGameCode.GDHealthTextObjects2.length = 0;
gdjs.MainGameCode.GDHealthTextObjects3.length = 0;
gdjs.MainGameCode.GDHealthTextObjects4.length = 0;
gdjs.MainGameCode.GDHealthTextObjects5.length = 0;
gdjs.MainGameCode.GDHealthTextObjects6.length = 0;
gdjs.MainGameCode.GDPick_95UpsObjects1.length = 0;
gdjs.MainGameCode.GDPick_95UpsObjects2.length = 0;
gdjs.MainGameCode.GDPick_95UpsObjects3.length = 0;
gdjs.MainGameCode.GDPick_95UpsObjects4.length = 0;
gdjs.MainGameCode.GDPick_95UpsObjects5.length = 0;
gdjs.MainGameCode.GDPick_95UpsObjects6.length = 0;
gdjs.MainGameCode.GDReset_95TimerObjects1.length = 0;
gdjs.MainGameCode.GDReset_95TimerObjects2.length = 0;
gdjs.MainGameCode.GDReset_95TimerObjects3.length = 0;
gdjs.MainGameCode.GDReset_95TimerObjects4.length = 0;
gdjs.MainGameCode.GDReset_95TimerObjects5.length = 0;
gdjs.MainGameCode.GDReset_95TimerObjects6.length = 0;
gdjs.MainGameCode.GDLeaderboard_95SubmitObjects1.length = 0;
gdjs.MainGameCode.GDLeaderboard_95SubmitObjects2.length = 0;
gdjs.MainGameCode.GDLeaderboard_95SubmitObjects3.length = 0;
gdjs.MainGameCode.GDLeaderboard_95SubmitObjects4.length = 0;
gdjs.MainGameCode.GDLeaderboard_95SubmitObjects5.length = 0;
gdjs.MainGameCode.GDLeaderboard_95SubmitObjects6.length = 0;
gdjs.MainGameCode.GDReset_95LeaderboardObjects1.length = 0;
gdjs.MainGameCode.GDReset_95LeaderboardObjects2.length = 0;
gdjs.MainGameCode.GDReset_95LeaderboardObjects3.length = 0;
gdjs.MainGameCode.GDReset_95LeaderboardObjects4.length = 0;
gdjs.MainGameCode.GDReset_95LeaderboardObjects5.length = 0;
gdjs.MainGameCode.GDReset_95LeaderboardObjects6.length = 0;
gdjs.MainGameCode.GDReset_95ButtonObjects1.length = 0;
gdjs.MainGameCode.GDReset_95ButtonObjects2.length = 0;
gdjs.MainGameCode.GDReset_95ButtonObjects3.length = 0;
gdjs.MainGameCode.GDReset_95ButtonObjects4.length = 0;
gdjs.MainGameCode.GDReset_95ButtonObjects5.length = 0;
gdjs.MainGameCode.GDReset_95ButtonObjects6.length = 0;
gdjs.MainGameCode.GDDarkeningObjects1.length = 0;
gdjs.MainGameCode.GDDarkeningObjects2.length = 0;
gdjs.MainGameCode.GDDarkeningObjects3.length = 0;
gdjs.MainGameCode.GDDarkeningObjects4.length = 0;
gdjs.MainGameCode.GDDarkeningObjects5.length = 0;
gdjs.MainGameCode.GDDarkeningObjects6.length = 0;
gdjs.MainGameCode.GDLeaderboardName_95InputObjects1.length = 0;
gdjs.MainGameCode.GDLeaderboardName_95InputObjects2.length = 0;
gdjs.MainGameCode.GDLeaderboardName_95InputObjects3.length = 0;
gdjs.MainGameCode.GDLeaderboardName_95InputObjects4.length = 0;
gdjs.MainGameCode.GDLeaderboardName_95InputObjects5.length = 0;
gdjs.MainGameCode.GDLeaderboardName_95InputObjects6.length = 0;
gdjs.MainGameCode.GDPause_95TextObjects1.length = 0;
gdjs.MainGameCode.GDPause_95TextObjects2.length = 0;
gdjs.MainGameCode.GDPause_95TextObjects3.length = 0;
gdjs.MainGameCode.GDPause_95TextObjects4.length = 0;
gdjs.MainGameCode.GDPause_95TextObjects5.length = 0;
gdjs.MainGameCode.GDPause_95TextObjects6.length = 0;
gdjs.MainGameCode.GDUpgrade_95TextObjects1.length = 0;
gdjs.MainGameCode.GDUpgrade_95TextObjects2.length = 0;
gdjs.MainGameCode.GDUpgrade_95TextObjects3.length = 0;
gdjs.MainGameCode.GDUpgrade_95TextObjects4.length = 0;
gdjs.MainGameCode.GDUpgrade_95TextObjects5.length = 0;
gdjs.MainGameCode.GDUpgrade_95TextObjects6.length = 0;

gdjs.MainGameCode.eventsList70(runtimeScene);
return;

}

gdjs['MainGameCode'] = gdjs.MainGameCode;
