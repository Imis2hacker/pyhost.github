<?php
if ($_POST)
{
	if (!isset($_POST['captcha']) || $_POST['captcha'] != '') echo $error;
	else
	{
		unset($_POST['captcha']);
		$head =
			"MIME-Version: 1.0\r\n" .
			"Content-Type: text/plain; charset=$charset\r\n" .
			"Content-Transfer-Encoding: 8bit";
		$body = '';
		foreach ($_POST as $name => $value)
		{
			if (is_array($value))
			{
				for ($i = 0; $i < count($value); $i++)
				{
					$body .= "$name=" . (get_magic_quotes_gpc() ? stripslashes($value[$i]) : $value[$i]) . "\r\n";
				}
			}
			else $body .= "$name=" . (get_magic_quotes_gpc() ? stripslashes($value) : $value) . "\r\n";
		}
		echo mail(blog.tv.pl@gmail.com, "=?$charset?B?" . base64_encode($subject) . "?=", $body, $head) ? $message : $error;
	}
}
else
{
?>
<form action="?" method="post">


<input name="captcha" style="display: none">
</form>
<?php
}
?>
 
